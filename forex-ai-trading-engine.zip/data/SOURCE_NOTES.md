# Historical data source investigation (Phase 2)

Investigated **2026-10-07**. No 5-year genuine EUR/USD H1 dataset was stored in this repo.

## Candidates

| Source | Identity | Access | Notes | Used? |
|---|---|---|---|---|
| User broker CSV | User's own export | User provides file | Best licence (your account). Bid/ask/mid depends on export. | Preferred path |
| OANDA v20 candles | OANDA | **API token required** (practice or live). Not present in this sandbox. | Documented REST. Bid/ask/mid available. Do not call without user credentials. | No — no credentials |
| Dukascopy historical | Dukascopy Bank SA | Web export / unofficial downloaders | Tick history exists; third-party bulk downloaders may conflict with terms. **No scraping.** User can export themselves. | No |
| Yahoo Finance `EURUSD=X` 1h via yfinance | Yahoo (unofficial library) | No key | Probe 2026-10-07: **12,349** hourly rows from **2024-10-07** to **2026-10-07** only (~2 years, not 5). Timezone mixed `+01:00`. Volume unused. Price type not documented as bid/ask. Yahoo ToS generally **forbids redistribution**; **not saved** into `data/`. | Probe only |

## Decision

**REAL HISTORICAL BACKTEST PENDING.**

Pipeline uses `data/synthetic_eurusd_h1.csv` (labelled synthetic) until the user drops a broker/OANDA CSV.

Do not invent prices. Do not fill gaps with fake candles.
