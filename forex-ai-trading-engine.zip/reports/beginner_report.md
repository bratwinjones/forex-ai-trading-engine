# Beginner explanation

**HISTORICAL BACKTEST ONLY — NOT LIVE TRADING RESULTS.**

This robot is a **rules checklist**, not a fortune teller. It watches two moving averages (EMA 20 and EMA 50).
When the fast average crosses above the slow one, it **buys** EUR/USD (long).
When it crosses below, it **sells** EUR/USD (short).
It tries to cut a loss at 1.5× ATR and take a profit at 2.0× ATR. Those numbers were **not** optimized.

Money at risk per trade is a small slice of the account (default 0.5%) measured to the stop.
A stop is **not** a promise: prices can jump over it (a gap).

## REAL HISTORICAL BACKTEST PENDING

The numbers below used **synthetic** (fake) candles so the software could be tested.
They are **not** EUR/USD market results. Do not use them to decide to trade live.

## development period
- Trades: 2 (**small sample — do not trust the win rate**)
- Start equity: 10000.0
- End equity: 10015.24389233441
- Total return: 0.0015243892334410702
- Max drawdown: 67.85453488999156 (0.00677075272089321)
- Win rate: 0.5
- Profit factor: 1.330366460031737
- Net P&L: 15.243892334410603  |  Gross P&L: 15.243892334410603
- Modeled extra costs field: 7.587216617946592

## validation period
- Trades: 1 (**small sample — do not trust the win rate**)
- Start equity: 10000.0
- End equity: 9954.103981981876
- Total return: -0.004589601801812387
- Max drawdown: 59.230607780144055 (0.005915173137298686)
- Win rate: 0.0
- Profit factor: 0.0
- Net P&L: -45.89601801812346  |  Gross P&L: -45.89601801812346
- Modeled extra costs field: 4.10398198187653

## holdout period
- Trades: 1 (**small sample — do not trust the win rate**)
- Start equity: 10000.0
- End equity: 10055.232096827005
- Total return: 0.005523209682700508
- Max drawdown: 58.17676146560552 (0.005795861287122521)
- Win rate: 1.0
- Profit factor: inf
- Net P&L: 55.23209682700564  |  Gross P&L: 55.23209682700564
- Modeled extra costs field: 4.001766663549361

## Were results consistent?
No / not enough evidence — periods disagree or sample is tiny.

## Did costs change the story?
Compare gross vs net in each split. Spread is already inside fill prices, so even 'gross' is not a zero-cost fantasy.

## Should we keep testing?
Keep testing **infrastructure and risk**, and only then a real broker CSV. A green synthetic or single-period result does **not** mean the strategy is profitable.
Do not describe this system as profitable because one slice of history (or fake data) went up.

HISTORICAL BACKTEST ONLY — NOT LIVE TRADING RESULTS.
