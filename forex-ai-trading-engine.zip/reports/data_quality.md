# Data quality report

- **source**: synthetic_eurusd_h1.csv (NOT genuine EUR/USD)
- **csv_path**: /home/user/fx-agent/data/synthetic_eurusd_h1.csv
- **audit_time_utc**: 2026-10-07T21:12:41.525920+00:00
- **download_date**: 2026-10-07T21:12:41.525920+00:00
- **date_range**: 2020-01-01 00:00:00+00:00 → 2020-01-17 15:00:00+00:00
- **n_candles**: 400
- **utc_timezone_ok**: True
- **chronological**: True
- **duplicate_timestamps**: 0
- **invalid_ohlc_rows**: 0
- **weekend_or_closure_gap_count**: 0
- **unexpected_missing_gap_count**: 0
- **large_jumps_ge_50_pips**: 0
- **zero_volume_bars**: 400
- **large_spread_bars**: None
- **invented_fill_candles**: 0 (must stay 0)

## Unexpected gaps (weekday holes)
- none flagged

## Limitations
- REAL HISTORICAL BACKTEST PENDING
- No candles were invented to fill gaps.

Gaps are **not** filled with synthetic candles.
