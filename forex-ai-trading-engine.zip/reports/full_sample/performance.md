# Backtest performance (infrastructure output, not proof of edge)

- **starting_equity**: 10000.0
- **ending_equity**: 10034.790118564737
- **total_return**: 0.0034790118564736986
- **total_trades**: 6
- **winning_trades**: 3
- **losing_trades**: 3
- **win_rate**: 0.5
- **average_win**: 57.37159089246933
- **average_loss**: -45.77488470422389
- **profit_factor**: 1.2533421168218768
- **expectancy_per_trade**: 5.798353094122718
- **max_drawdown_money**: 104.53719826551969
- **max_drawdown_pct**: 0.01042390868896846
- **largest_win**: 61.38626505876699
- **largest_loss**: -46.142372724356385
- **consecutive_wins**: 2
- **consecutive_losses**: 2
- **costs_paid**: 24.044939824604274

## Assumptions / notes
- fill_on=next_open: signal on bar i close fills at bar i+1 open (with spread/slippage).
- sl_tp_ambiguity=conservative: if both SL and TP lie inside a candle range, SL is assumed.
- Gap through stop: fill at the more adverse of stop vs bar OPEN (stop is not a max-loss guarantee).
- EURUSD USD PnL = units_EUR * price_change (pip = 0.0001; 10k units * 10 pips = $10 gross).
- spread/slippage values are configurable RESEARCH ASSUMPTIONS, not broker quotes.
- balance = realized cash; equity = balance + unrealized mark-to-bid/ask.

Successful software tests or a synthetic-data run are **not** evidence of trading profitability.