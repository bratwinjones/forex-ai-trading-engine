# Backtest performance (infrastructure output, not proof of edge)

- **starting_equity**: 10000.0
- **ending_equity**: 10055.232096827005
- **total_return**: 0.005523209682700508
- **total_trades**: 1
- **winning_trades**: 1
- **losing_trades**: 0
- **win_rate**: 1.0
- **average_win**: 55.23209682700564
- **average_loss**: 0.0
- **profit_factor**: inf
- **expectancy_per_trade**: 55.23209682700564
- **max_drawdown_money**: 58.17676146560552
- **max_drawdown_pct**: 0.005795861287122521
- **largest_win**: 55.23209682700564
- **largest_loss**: 55.23209682700564
- **consecutive_wins**: 1
- **consecutive_losses**: 0
- **costs_paid**: 4.001766663549361

## Assumptions / notes
- fill_on=next_open: signal on bar i close fills at bar i+1 open (with spread/slippage).
- sl_tp_ambiguity=conservative: if both SL and TP lie inside a candle range, SL is assumed.
- Gap through stop: fill at the more adverse of stop vs bar OPEN (stop is not a max-loss guarantee).
- EURUSD USD PnL = units_EUR * price_change (pip = 0.0001; 10k units * 10 pips = $10 gross).
- spread/slippage values are configurable RESEARCH ASSUMPTIONS, not broker quotes.
- balance = realized cash; equity = balance + unrealized mark-to-bid/ask.

Successful software tests or a synthetic-data run are **not** evidence of trading profitability.
## Extended (Phase 2)
- **split**: holdout
- **annualized_return**: nan
- **gross_pnl_sum**: 55.23209682700564
- **net_pnl_sum**: 55.23209682700564
- **average_holding_hours**: 19.0
- **long_trades**: 0 pnl=0.0
- **short_trades**: 1 pnl=55.23209682700564
- **small_sample**: True

Gross vs net: net includes modeled commissions; spread/slippage is already in fill prices.
Do not claim statistical significance from these figures.

### Monthly returns
- 2020-01: 0.5523%