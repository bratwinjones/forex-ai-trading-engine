# Backtest performance (infrastructure output, not proof of edge)

- **starting_equity**: 10000.0
- **ending_equity**: 10015.24389233441
- **total_return**: 0.0015243892334410702
- **total_trades**: 2
- **winning_trades**: 1
- **losing_trades**: 1
- **win_rate**: 0.5
- **average_win**: 61.38626505876699
- **average_loss**: -46.142372724356385
- **profit_factor**: 1.330366460031737
- **expectancy_per_trade**: 7.6219461672053015
- **max_drawdown_money**: 67.85453488999156
- **max_drawdown_pct**: 0.00677075272089321
- **largest_win**: 61.38626505876699
- **largest_loss**: -46.142372724356385
- **consecutive_wins**: 1
- **consecutive_losses**: 1
- **costs_paid**: 7.587216617946592

## Assumptions / notes
- fill_on=next_open: signal on bar i close fills at bar i+1 open (with spread/slippage).
- sl_tp_ambiguity=conservative: if both SL and TP lie inside a candle range, SL is assumed.
- Gap through stop: fill at the more adverse of stop vs bar OPEN (stop is not a max-loss guarantee).
- EURUSD USD PnL = units_EUR * price_change (pip = 0.0001; 10k units * 10 pips = $10 gross).
- spread/slippage values are configurable RESEARCH ASSUMPTIONS, not broker quotes.
- balance = realized cash; equity = balance + unrealized mark-to-bid/ask.

Successful software tests or a synthetic-data run are **not** evidence of trading profitability.
## Extended (Phase 2)
- **split**: development
- **annualized_return**: nan
- **gross_pnl_sum**: 15.243892334410603
- **net_pnl_sum**: 15.243892334410603
- **average_holding_hours**: 6.5
- **long_trades**: 1 pnl=-46.142372724356385
- **short_trades**: 1 pnl=61.38626505876699
- **small_sample**: True

Gross vs net: net includes modeled commissions; spread/slippage is already in fill prices.
Do not claim statistical significance from these figures.

### Monthly returns
- 2020-01: 0.1524%