# Backtest performance (infrastructure output, not proof of edge)

- **starting_equity**: 10000.0
- **ending_equity**: 9954.103981981876
- **total_return**: -0.004589601801812387
- **total_trades**: 1
- **winning_trades**: 0
- **losing_trades**: 1
- **win_rate**: 0.0
- **average_win**: 0.0
- **average_loss**: -45.89601801812346
- **profit_factor**: 0.0
- **expectancy_per_trade**: -45.89601801812346
- **max_drawdown_money**: 59.230607780144055
- **max_drawdown_pct**: 0.005915173137298686
- **largest_win**: -45.89601801812346
- **largest_loss**: -45.89601801812346
- **consecutive_wins**: 0
- **consecutive_losses**: 1
- **costs_paid**: 4.10398198187653

## Assumptions / notes
- fill_on=next_open: signal on bar i close fills at bar i+1 open (with spread/slippage).
- sl_tp_ambiguity=conservative: if both SL and TP lie inside a candle range, SL is assumed.
- Gap through stop: fill at the more adverse of stop vs bar OPEN (stop is not a max-loss guarantee).
- EURUSD USD PnL = units_EUR * price_change (pip = 0.0001; 10k units * 10 pips = $10 gross).
- spread/slippage values are configurable RESEARCH ASSUMPTIONS, not broker quotes.
- balance = realized cash; equity = balance + unrealized mark-to-bid/ask.

Successful software tests or a synthetic-data run are **not** evidence of trading profitability.
## Extended (Phase 2)
- **split**: validation
- **annualized_return**: nan
- **gross_pnl_sum**: -45.89601801812346
- **net_pnl_sum**: -45.89601801812346
- **average_holding_hours**: 14.0
- **long_trades**: 1 pnl=-45.89601801812346
- **short_trades**: 0 pnl=0.0
- **small_sample**: True

Gross vs net: net includes modeled commissions; spread/slippage is already in fill prices.
Do not claim statistical significance from these figures.

### Monthly returns
- 2020-01: -0.4590%