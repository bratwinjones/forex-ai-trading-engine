# Backtest performance (infrastructure output, not proof of edge)

- **starting_equity**: 10000.0
- **ending_equity**: 10036.475588542095
- **total_return**: 0.0036475588542094557
- **total_trades**: 6
- **winning_trades**: 3
- **losing_trades**: 3
- **win_rate**: 0.5
- **average_win**: 62.12950451403176
- **average_loss**: -49.97097500000001
- **profit_factor**: 1.2433118327995751
- **expectancy_per_trade**: 6.079264757015879
- **max_drawdown_money**: 114.46360954709417
- **max_drawdown_pct**: 0.011411118834896155
- **largest_win**: 66.33333333333333
- **largest_loss**: -50.08166666666667
- **consecutive_wins**: 2
- **consecutive_losses**: 2
- **costs_paid**: 26.157614499484204

## Assumptions / notes
- fill_on=next_open: signal on bar i close fills at bar i+1 open (with spread/slippage).
- sl_tp_ambiguity=conservative: if both SL and TP lie inside a candle range, SL is assumed.
- spread/slippage values are configurable RESEARCH ASSUMPTIONS, not broker quotes.

Successful software tests or a synthetic-data run are **not** evidence of trading profitability.