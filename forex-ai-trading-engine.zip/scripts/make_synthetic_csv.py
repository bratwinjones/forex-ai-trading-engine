"""Write an obviously-synthetic OHLC series. Not market data."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd


def make_synthetic(n: int = 400, seed: int = 7) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    # Deterministic toy path — labelled synthetic.
    rets = rng.normal(0, 0.0008, size=n)
    close = 1.0800 * np.exp(np.cumsum(rets))
    open_ = np.concatenate([[1.0800], close[:-1]])
    wiggle = np.abs(rng.normal(0.0004, 0.0002, size=n))
    high = np.maximum(open_, close) + wiggle
    low = np.minimum(open_, close) - wiggle
    ts = pd.date_range("2020-01-01", periods=n, freq="h", tz="UTC")
    return pd.DataFrame(
        {
            "timestamp": ts,
            "open": open_,
            "high": high,
            "low": low,
            "close": close,
            "volume": 0,
        }
    )


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    df = make_synthetic()
    out = root / "data" / "synthetic_eurusd_h1.csv"
    df.to_csv(out, index=False)
    print(f"Wrote {out} ({len(df)} synthetic bars). NOT genuine EUR/USD.")
