#!/usr/bin/env python3
"""Session handoff PDF for the parallel design agent."""
from fpdf import FPDF
from pathlib import Path

OUT = Path("/home/user/fx-agent/reports/SESSION_HANDOFF_Phase1.pdf")


class PDF(FPDF):
    def header(self):
        if self.page_no() == 1:
            return
        self.set_font("Helvetica", "I", 8)
        self.set_text_color(90, 90, 90)
        self.cell(0, 8, "Session handoff  |  fx-agent Phase 1  |  Feed this to the parallel design agent", new_x="LMARGIN", new_y="NEXT")
        self.set_draw_color(20, 45, 80)
        self.line(15, 14, 195, 14)
        self.ln(3)

    def footer(self):
        self.set_y(-14)
        self.set_font("Helvetica", "I", 8)
        self.set_text_color(110, 110, 110)
        self.cell(0, 8, f"Page {self.page_no()}/{{nb}}  |  Arena.ai sandbox  |  Not a profitability claim", align="C")


def h1(pdf, t):
    pdf.ln(2)
    pdf.set_font("Helvetica", "B", 14)
    pdf.set_text_color(20, 45, 80)
    pdf.multi_cell(0, 7, t)
    pdf.set_draw_color(20, 45, 80)
    pdf.line(15, pdf.get_y(), 195, pdf.get_y())
    pdf.ln(3)


def h2(pdf, t):
    pdf.ln(1.5)
    pdf.set_font("Helvetica", "B", 11)
    pdf.set_text_color(30, 64, 111)
    pdf.multi_cell(0, 6, t)
    pdf.ln(0.5)


def body(pdf, t):
    pdf.set_font("Helvetica", "", 10)
    pdf.set_text_color(25, 25, 25)
    pdf.multi_cell(0, 5.2, t)
    pdf.ln(1.2)


def bullet(pdf, t):
    pdf.set_font("Helvetica", "", 10)
    pdf.set_text_color(25, 25, 25)
    pdf.cell(6, 5.2, chr(149))
    pdf.multi_cell(0, 5.2, t)
    pdf.ln(0.3)


def mono(pdf, t):
    pdf.set_font("Courier", "", 8)
    pdf.set_text_color(20, 20, 20)
    pdf.set_fill_color(245, 247, 250)
    pdf.multi_cell(0, 4.4, t, fill=True)
    pdf.ln(1.5)


pdf = PDF()
pdf.alias_nb_pages()
pdf.set_auto_page_break(True, 18)
pdf.set_margins(15, 16, 15)
pdf.add_page()

pdf.set_fill_color(20, 45, 80)
pdf.rect(0, 0, 210, 46, "F")
pdf.set_fill_color(46, 125, 50)
pdf.rect(0, 46, 210, 3, "F")
pdf.set_xy(15, 10)
pdf.set_font("Helvetica", "B", 18)
pdf.set_text_color(255, 255, 255)
pdf.cell(180, 8, "Session handoff PDF", new_x="LMARGIN", new_y="NEXT")
pdf.set_x(15)
pdf.set_font("Helvetica", "B", 12)
pdf.cell(180, 7, "fx-agent  |  Phase 1 research foundation", new_x="LMARGIN", new_y="NEXT")
pdf.set_x(15)
pdf.set_font("Helvetica", "", 9)
pdf.set_text_color(210, 220, 235)
pdf.cell(180, 5, "For the parallel design agent  |  Arena.ai implementer  |  Do not treat as a trading edge", new_x="LMARGIN", new_y="NEXT")

pdf.set_xy(15, 54)
pdf.set_font("Helvetica", "B", 10)
pdf.set_text_color(46, 90, 40)
body(pdf, "USER WORKFLOW (confirmed): One agent designs; this sandbox agent implements. After every session, produce a PDF of what was done so it can be fed to the other tool (parallel agents, Grok-style). This file is that handoff.")

h1(pdf, "0. How to use this document")
bullet(pdf, "Give this PDF to the other AI as the source of truth for what exists in /home/user/fx-agent/.")
bullet(pdf, "The other AI should propose the NEXT phase only; this agent will implement in the sandbox.")
bullet(pdf, "Beginner-profit goal is acknowledged as the USER intent. Phase 1 still forbids live/demo broker orders and does not claim profits.")
bullet(pdf, "Each future session should emit reports/SESSION_HANDOFF_<name>.pdf the same way.")

h1(pdf, "1. User intent (plain language)")
body(pdf, "The user is a beginner who wants a functional AI forex agent aimed at making profits. Two AIs work in parallel: a designer (other tool) and an implementer (this Arena.ai sandbox). They asked for a PDF of everything done per session to close the loop.")
body(pdf, "Safety bound already agreed: no live-money until after testing; Phase 1 is research/backtest only.")

h1(pdf, "2. Environment (implementer sandbox) - short")
bullet(pdf, "Debian 13, Python 3.13.14, pandas/numpy/matplotlib/pytest/PyYAML present. ~1.9 GiB RAM, no swap.")
bullet(pdf, "No MT5, no Wine, no IB Gateway, no Docker, no cron. HTTPS outbound works; vendor APIs may 403.")
bullet(pdf, "Persist files under /home/user. .venv/node_modules may NOT survive snapshots.")
bullet(pdf, "Background processes exist in-session only - not a 24/5 VPS. Unsuitable as sole live executor.")
bullet(pdf, "Full capability report also exists: /home/user/FX_Agent_Environment_Capability_Report.pdf")

h1(pdf, "3. What was implemented this session")
body(pdf, "Phase 1 of the design prompt: trustworthy research/backtesting foundation. Python 3.13 under /home/user/fx-agent/.")
h2(pdf, "Tree")
mono(pdf, """/home/user/fx-agent/
  README.md
  requirements.txt
  config/default.yaml
  data/synthetic_eurusd_h1.csv     # SYNTHETIC, not EURUSD market
  data/README.md
  src/ingest/   loader.py validate.py
  src/strategy/ base.py ema_trend.py
  src/risk/     engine.py
  src/backtest/ engine.py report.py
  src/paper/    broker.py          # raises if you try to place orders
  src/run.py
  tests/        test_validation.py test_execution.py test_risk.py
  reports/      performance.md trade_ledger.csv equity_curve.*
  scripts/      make_synthetic_csv.py""")

h2(pdf, "Behaviour locked in")
bullet(pdf, "Canonical OHLC: timestamp, open, high, low, close; optional volume, spread.")
bullet(pdf, "Validation FAILS LOUDLY: UTC, chronological, no dupes, OHLC inequalities, positive prices. No silent repair.")
bullet(pdf, "Local CSV only. No Yahoo/broker download.")
bullet(pdf, "Bar-by-bar engine; signal on bar i close; fill at bar i+1 OPEN; bid/ask spread + slippage.")
bullet(pdf, "Long/short/flat; SL and TP; cash/equity; full fill ledger.")
bullet(pdf, "Ambiguity policy conservative: if SL and TP both inside one candle, assume SL. Documented.")
bullet(pdf, "Risk module sizes by % equity at risk to stop; max risk/trade, exposure, simultaneous positions, daily loss, drawdown circuit breaker. Strategy cannot bypass.")
bullet(pdf, "ONE baseline: EMA 20/50, ATR 14, stop 1.5x ATR, target 2.0x ATR. NOT optimized.")
bullet(pdf, "No LLM BUY/SELL. No martingale/grid/averaging-down. No leverage optimization. No ML.")

h1(pdf, "4. How to run (for the other agent / user)")
mono(pdf, """cd /home/user/fx-agent
PYTHONPATH=. python -m pytest tests -q
PYTHONPATH=. python -m src.run --config config/default.yaml --out reports
# real data later:
# PYTHONPATH=. python -m src.run --csv /path/to/eurusd_h1.csv --out reports""")

h1(pdf, "5. Test results this session")
body(pdf, "pytest: 14 passed, 0 failed. Coverage: no look-ahead fill, spread (long pays ask), SL, TP, ambiguous SL/TP -> SL, position sizing math, drawdown breaker, malformed OHLC rejection.")
body(pdf, "Synthetic plumbing backtest (NOT market evidence): 6 trades on 400 fake H1 bars, start 10000, end ~10036. Do not interpret as edge.")

h1(pdf, "6. Honest status vs beginner profit goal")
bullet(pdf, "NOT a working live trader.")
bullet(pdf, "NOT connected to OANDA/MT5/IB.")
bullet(pdf, "NOT using genuine EUR/USD history - genuine historical backtest PENDING.")
bullet(pdf, "PaperBroker.place_order() raises RuntimeError by design.")
bullet(pdf, "Passing tests != profitability. Green synthetic equity != skill.")
body(pdf, "A beginner still needs: real H1 EURUSD CSV, out-of-sample tests, paper trading, education on risk of ruin. This codebase is the lab bench, not an ATM.")

h1(pdf, "7. Config assumptions (not broker truth)")
mono(pdf, """instrument EURUSD H1
initial_equity 10000 USD
spread 0.00015   # ~1.5 pips ASSUMPTION
slippage 0.00002
fill_on next_open
sl_tp_ambiguity conservative
risk_fraction_per_trade 0.005 (0.5% equity to stop)
max_risk 0.01, max_daily_loss 0.02, max_dd 0.10, max_positions 1""")

h1(pdf, "8. Suggested next phase for the DESIGN agent")
body(pdf, "Do not jump to live money. Proposed Phase 2 (design, then this sandbox implements):")
bullet(pdf, "Specify a genuine EURUSD H1 CSV schema + where the user gets it legally (their broker export).")
bullet(pdf, "Walk-forward / train-test time split reporting (still no parameter hunt unless user insists, then constrain it).")
bullet(pdf, "Beginner dashboard: equity, open risk, 'this is simulated' banners.")
bullet(pdf, "In-process paper loop on replayed bars (still no broker).")
bullet(pdf, "Keep risk gates mandatory; refuse martingale.")
bullet(pdf, "Optional later: OANDA PRACTICE REST only, after paper metrics and user explicit go-ahead.")

h1(pdf, "9. Contract between the two agents")
bullet(pdf, "Designer (other tool): architecture, prompts, checklists, what NOT to do.")
bullet(pdf, "Implementer (this sandbox): code, tests, reports, session PDF.")
bullet(pdf, "User: feeds each session PDF back to the designer; never treats sandbox PnL as live money.")
bullet(pdf, "If a request is live orders / recovery sizing / fabricating results, implementer refuses.")

h1(pdf, "10. Files the designer should cite")
bullet(pdf, "/home/user/fx-agent/README.md")
bullet(pdf, "/home/user/fx-agent/config/default.yaml")
bullet(pdf, "/home/user/fx-agent/src/backtest/engine.py")
bullet(pdf, "/home/user/fx-agent/src/risk/engine.py")
bullet(pdf, "/home/user/FX_Agent_Environment_Capability_Report.pdf")
bullet(pdf, "This file: /home/user/fx-agent/reports/SESSION_HANDOFF_Phase1.pdf")

pdf.ln(4)
pdf.set_font("Helvetica", "B", 10)
pdf.set_text_color(20, 45, 80)
body(pdf, "End of session handoff. Next session: implementer will append or write SESSION_HANDOFF_<phase>.pdf again.")

OUT.parent.mkdir(parents=True, exist_ok=True)
pdf.output(str(OUT))
print(OUT)
