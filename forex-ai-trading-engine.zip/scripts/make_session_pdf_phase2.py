#!/usr/bin/env python3
from pathlib import Path
from fpdf import FPDF

OUT = Path("/home/user/fx-agent/reports/SESSION_HANDOFF_Phase2.pdf")


class PDF(FPDF):
    def header(self):
        if self.page_no() == 1:
            return
        self.set_font("Helvetica", "I", 8)
        self.set_text_color(90, 90, 90)
        self.cell(0, 8, "SESSION_HANDOFF_Phase2  |  Feed to design agent", new_x="LMARGIN", new_y="NEXT")
        self.line(15, 14, 195, 14)
        self.ln(3)

    def footer(self):
        self.set_y(-14)
        self.set_font("Helvetica", "I", 8)
        self.set_text_color(110, 110, 110)
        self.cell(0, 8, f"Page {self.page_no()}/{{nb}}  |  REAL HISTORICAL BACKTEST PENDING  |  Not live trading", align="C")


def h1(pdf, t):
    pdf.ln(2)
    pdf.set_font("Helvetica", "B", 13)
    pdf.set_text_color(20, 45, 80)
    pdf.multi_cell(0, 7, t)
    pdf.line(15, pdf.get_y(), 195, pdf.get_y())
    pdf.ln(2)


def body(pdf, t):
    pdf.set_font("Helvetica", "", 10)
    pdf.set_text_color(25, 25, 25)
    pdf.multi_cell(0, 5.1, t)
    pdf.ln(1)


def bullet(pdf, t):
    pdf.set_font("Helvetica", "", 10)
    pdf.set_text_color(25, 25, 25)
    pdf.cell(6, 5.1, chr(149))
    pdf.multi_cell(0, 5.1, t)
    pdf.ln(0.25)


pdf = PDF()
pdf.alias_nb_pages()
pdf.set_auto_page_break(True, 18)
pdf.set_margins(15, 16, 15)
pdf.add_page()
pdf.set_fill_color(20, 45, 80)
pdf.rect(0, 0, 210, 42, "F")
pdf.set_fill_color(180, 80, 40)
pdf.rect(0, 42, 210, 3, "F")
pdf.set_xy(15, 10)
pdf.set_font("Helvetica", "B", 16)
pdf.set_text_color(255, 255, 255)
pdf.cell(180, 8, "Session handoff  |  Phase 2", new_x="LMARGIN", new_y="NEXT")
pdf.set_x(15)
pdf.set_font("Helvetica", "", 10)
pdf.set_text_color(230, 230, 230)
pdf.cell(180, 6, "REAL HISTORICAL BACKTEST PENDING  |  Arena.ai implementer  |  2026-10-07", new_x="LMARGIN", new_y="NEXT")

pdf.set_xy(15, 50)

h1(pdf, "1. Project status")
body(pdf, "Phase 2 extended /home/user/fx-agent/ without a rebuild. Still NO broker, NO demo/live orders, NO ML, NO parameter optimization, NO martingale/grid/averaging.")
body(pdf, "Genuine 5-year EUR/USD H1 was NOT obtained. Yahoo 1h probe showed only ~2 years (2024-10-07 to 2026-10-07), unofficial API, unclear bid/ask, ToS redistribution risk - prices were NOT saved. OANDA needs a token (absent). Dukascopy was not scraped.")
body(pdf, "REAL HISTORICAL BACKTEST PENDING. Split reports below are SYNTHETIC plumbing only. Small samples. Not an edge.")

h1(pdf, "2. Files created")
for t in [
    "data/SOURCE_NOTES.md",
    "src/ingest/quality.py",
    "src/backtest/splits.py",
    "src/backtest/analytics.py",
    "tests/test_phase2.py",
    "reports/data_quality.md",
    "reports/beginner_report.md",
    "reports/full_sample/*",
    "reports/splits/{development,validation,holdout}/*",
    "reports/SESSION_HANDOFF_Phase2.pdf (this file)",
    "scripts/make_session_pdf_phase2.py",
]:
    bullet(pdf, t)

h1(pdf, "3. Files modified")
for t in [
    "src/backtest/engine.py - gap fills, balance/unrealized/equity, trade_start warmup, extra cost on size",
    "src/risk/engine.py - extra_cost_per_unit in sizing; stop is not max-loss",
    "src/run.py - quality audit + 60/20/20 splits + beginner report",
    "config/default.yaml - genuine_historical: false",
]:
    bullet(pdf, t)

h1(pdf, "4. Historical data source")
bullet(pdf, "Stored dataset: data/synthetic_eurusd_h1.csv - FAKE (400 H1 bars, 2020-01-01 to 2020-01-17 UTC).")
bullet(pdf, "OANDA: documented REST, credentials required - not used.")
bullet(pdf, "User broker CSV: preferred next input.")
bullet(pdf, "Yahoo EURUSD=X 1h: 12349 rows ~2y only; NOT stored.")
body(pdf, "REAL HISTORICAL BACKTEST PENDING.")

h1(pdf, "5. Data quality findings (synthetic file)")
bullet(pdf, "n_candles=400; UTC ok; chronological; 0 dupes; 0 invalid OHLC")
bullet(pdf, "weekend_or_closure_gap_count=0 (synthetic has no weekend)")
bullet(pdf, "unexpected_missing_gap_count=0")
bullet(pdf, "zero_volume_bars=400 (volume column is dummy zeros)")
bullet(pdf, "invented_fill_candles=0")
body(pdf, "Quality module distinguishes weekend vs weekday holes; does not invent bars.")

h1(pdf, "6. Backtester accounting audit")
body(pdf, "EURUSD USD P&L = units_EUR * price_change. Example locked by test: 10,000 EUR * 0.0010 = $10 gross. Pip value: 10,000 * 0.0001 = $1/pip.")
body(pdf, "Defects found and corrected:")
bullet(pdf, "Sizing ignored spread/slippage. Now units = risk_cash / (stop_dist + extra_cost_per_unit) with extra = spread + 2*slippage + commission_per_unit.")
bullet(pdf, "SL filled at stop even after an adverse gap. Now if open gaps through stop, fill OPEN (stop_loss_gap). Stop is NOT a max-loss guarantee.")
bullet(pdf, "No balance vs equity. Now balance=realized cash, unrealized=mark bid/ask, equity=sum.")
body(pdf, "Conservative SL/TP ambiguity unchanged. Bid/ask + slippage on entry/mark. Daily-loss and drawdown breakers use equity.")

h1(pdf, "7. Test results")
body(pdf, "Complete suite: 25 passed, 0 failed, 0 skipped (pytest tests/). Passing tests != financial completeness of live markets.")

h1(pdf, "8-10. Split results (SYNTHETIC - not EURUSD)")
body(pdf, "Unoptimized EMA20/50 ATR14 SL1.5 TP2.0. Chronological 60/20/20. Warmup 60 bars, no trades before trade_start. Do NOT pick the best window.")
bullet(pdf, "Development: trades=2 (small sample), start=10000, end~10015.24, return=+0.152%, maxDD~67.85 (0.68%), win rate=0.5, PF~1.33, net PnL~+15.24")
bullet(pdf, "Validation: trades=1 (small sample), start=10000, end~9954.10, return=-0.459%, maxDD~59.23, win rate=0, PF=0, net PnL~-45.90")
bullet(pdf, "Holdout: trades=1 (small sample), start=10000, end~10055.23, return=+0.552%, net PnL from run print")
body(pdf, "Signs disagree across splits. Costs/spread in fills. No statistical significance. Holdout is independent of parameter search (parameters never optimized; still, synthetic data means holdout is not a market test).")

h1(pdf, "11. Discovered bugs")
bullet(pdf, "Risk size omitted execution costs - fixed.")
bullet(pdf, "Gap-through-stop filled at stop - fixed.")
bullet(pdf, "Missing unrealized/balance - fixed.")
bullet(pdf, "run.py Timestamp tz double-apply - fixed during Phase 2 run.")

h1(pdf, "12. Remaining limitations")
bullet(pdf, "No genuine EURUSD history in repo.")
bullet(pdf, "No swaps, no session filter, no partial fills, no leverage model.")
bullet(pdf, "Sandbox is not 24/5. 1.9 GiB RAM.")
bullet(pdf, "Synthetic quality report cannot show real weekend holes.")
bullet(pdf, "Beginner profit goal is NOT met. Do not go live.")

h1(pdf, "13. Recommended next phase (for design agent)")
bullet(pdf, "Phase 3 only after user supplies broker/OANDA H1 CSV (years of data).")
bullet(pdf, "Re-run quality + splits on REAL series; keep params frozen.")
bullet(pdf, "Paper replay UI with 'NOT LIVE' banner.")
bullet(pdf, "Still no live/demo orders until a later explicit authorization.")
body(pdf, "HISTORICAL BACKTEST ONLY - NOT LIVE TRADING RESULTS.")
body(pdf, "REAL HISTORICAL BACKTEST PENDING.")

OUT.parent.mkdir(parents=True, exist_ok=True)
pdf.output(str(OUT))
print(OUT)
