import pandas as pd
import pytest

from src.ingest.validate import ValidationError, validate_ohlc


def _ok():
    return pd.DataFrame(
        {
            "timestamp": ["2020-01-01T00:00:00Z", "2020-01-01T01:00:00Z"],
            "open": [1.1, 1.11],
            "high": [1.12, 1.13],
            "low": [1.09, 1.10],
            "close": [1.11, 1.12],
        }
    )


def test_valid_passes():
    out = validate_ohlc(_ok())
    assert len(out) == 2
    assert str(out["timestamp"].dt.tz) == "UTC"


def test_high_below_close_rejected():
    df = _ok()
    df.loc[0, "high"] = 1.0
    with pytest.raises(ValidationError, match="high"):
        validate_ohlc(df)


def test_duplicate_timestamps_rejected():
    df = _ok()
    df.loc[1, "timestamp"] = df.loc[0, "timestamp"]
    with pytest.raises(ValidationError, match="Duplicate"):
        validate_ohlc(df)


def test_non_chronological_rejected():
    df = _ok()
    df.loc[0, "timestamp"] = "2020-01-02T00:00:00Z"
    with pytest.raises(ValidationError, match="chronological"):
        validate_ohlc(df)


def test_non_positive_rejected():
    df = _ok()
    df.loc[0, "low"] = -0.1
    with pytest.raises(ValidationError):
        validate_ohlc(df)


def test_missing_column_rejected():
    df = _ok().drop(columns=["close"])
    with pytest.raises(ValidationError, match="Missing"):
        validate_ohlc(df)
