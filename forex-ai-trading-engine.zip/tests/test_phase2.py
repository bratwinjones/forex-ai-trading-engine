"""Phase 2 accounting, splits, quality. Synthetic bars only — not a profit claim."""

from datetime import datetime, timezone

import pandas as pd
import pytest

from src.backtest.analytics import directional_pnl_usd, pip_value_usd
from src.backtest.engine import BacktestEngine
from src.backtest.splits import chronological_splits
from src.ingest.quality import audit_ohlc, expected_fx_weekend
from src.risk.engine import RiskEngine
from src.strategy.base import Signal
from src.strategy.ema_trend import EmaTrendStrategy
from tests.helpers import bars_from_rows, default_config, make_risk, run_scripted


def test_pip_value_and_usd_pnl():
    # 10_000 EUR * 0.0010 = $10
    assert pip_value_usd(10_000, 0.0001) == pytest.approx(1.0)
    assert directional_pnl_usd(10_000, 0.0010, "long") == pytest.approx(10.0)
    assert directional_pnl_usd(10_000, 0.0010, "short") == pytest.approx(-10.0)


def test_usd_pnl_in_engine():
    ts = pd.date_range("2020-01-06 08:00", periods=4, freq="h", tz="UTC")
    # flat then fill then close at +0.0010 on mid; we check units * delta on fills
    rows = [
        {"timestamp": ts[0], "open": 1.1000, "high": 1.1005, "low": 1.0995, "close": 1.1000},
        {"timestamp": ts[1], "open": 1.1000, "high": 1.1005, "low": 1.0995, "close": 1.1000},
        {"timestamp": ts[2], "open": 1.1000, "high": 1.1005, "low": 1.0995, "close": 1.1000},  # fill
        {"timestamp": ts[3], "open": 1.1010, "high": 1.2000, "low": 1.1009, "close": 1.1010},  # TP far
    ]
    df = bars_from_rows(rows)
    cfg = default_config()
    cfg["costs"] = {**cfg["costs"], "spread": 0.0, "slippage": 0.0}
    cfg["risk"]["risk_fraction_per_trade"] = 0.01
    cfg["risk"]["max_risk_fraction_per_trade"] = 0.01
    sig = Signal(side="long", stop_distance=0.0100, target_distance=0.0010)
    result, _ = run_scripted(df, emit_at=1, signal=sig, cfg=cfg)
    assert not result.trades.empty
    # 1% of 10k = 100 risk / 0.01 stop = 10_000 units; TP +0.0010 => $10
    tr = result.trades.iloc[0]
    assert tr["units"] == pytest.approx(10_000, rel=1e-6)
    assert tr["gross_pnl"] == pytest.approx(10.0, rel=1e-6)


def test_position_sizing_includes_costs():
    risk = RiskEngine(
        risk_fraction_per_trade=0.01,
        max_risk_fraction_per_trade=0.01,
        max_aggregate_exposure_units=1e12,
        max_simultaneous_positions=1,
        max_daily_loss_fraction=0.5,
        max_drawdown_fraction=0.5,
        initial_equity=10_000,
    )
    no_cost = risk.size_from_stop(equity=10_000, entry_price=1.2, stop_price=1.19)
    with_cost = risk.size_from_stop(
        equity=10_000, entry_price=1.2, stop_price=1.19, extra_cost_per_unit=0.0002
    )
    assert with_cost < no_cost
    assert no_cost == pytest.approx(10_000)


def test_spread_slippage_long_pays_ask_short_pays_bid():
    df_rows = []
    ts = pd.date_range("2020-01-06", periods=5, freq="h", tz="UTC")
    for t in ts:
        df_rows.append({"timestamp": t, "open": 1.2, "high": 1.201, "low": 1.199, "close": 1.2})
    df = bars_from_rows(df_rows)
    cfg = default_config()
    sig = Signal(side="long", stop_distance=0.05, target_distance=0.05)
    res, _ = run_scripted(df, 0, sig, cfg)
    entry = next(f for f in res.fills if f.action == "enter")
    mid = 1.2
    expect = mid + cfg["costs"]["spread"] / 2 + cfg["costs"]["slippage"]
    assert entry.price == pytest.approx(expect)


def test_stop_loss_gap_uses_open_not_stop():
    ts = pd.date_range("2020-01-06 08:00", periods=5, freq="h", tz="UTC")
    prices = [
        (1.10, 1.101, 1.099, 1.100),
        (1.10, 1.101, 1.099, 1.100),
        (1.10, 1.101, 1.099, 1.100),  # signal
        (1.10, 1.101, 1.099, 1.100),  # fill ~1.10
        (1.07, 1.08, 1.06, 1.075),  # gap open through stop
    ]
    rows = [
        {"timestamp": t, "open": o, "high": h, "low": l, "close": c}
        for t, (o, h, l, c) in zip(ts, prices)
    ]
    df = bars_from_rows(rows)
    sig = Signal(side="long", stop_distance=0.01, target_distance=0.05)
    cfg = default_config()
    cfg["costs"] = {**cfg["costs"], "spread": 0.0, "slippage": 0.0}
    res, _ = run_scripted(df, 2, sig, cfg)
    ex = next(f for f in res.fills if f.action == "exit")
    assert ex.reason == "stop_loss_gap"
    assert ex.price == pytest.approx(1.07)


def test_unrealized_and_equity_vs_balance():
    ts = pd.date_range("2020-01-06 08:00", periods=5, freq="h", tz="UTC")
    prices = [
        (1.10, 1.11, 1.09, 1.10),
        (1.10, 1.11, 1.09, 1.10),
        (1.10, 1.11, 1.09, 1.10),
        (1.10, 1.11, 1.09, 1.10),  # fill
        (1.10, 1.11, 1.09, 1.105),  # still open, no SL/TP
    ]
    rows = [
        {"timestamp": t, "open": o, "high": h, "low": l, "close": c}
        for t, (o, h, l, c) in zip(ts, prices)
    ]
    df = bars_from_rows(rows)
    sig = Signal(side="long", stop_distance=0.05, target_distance=0.05)
    cfg = default_config()
    res, _ = run_scripted(df, 2, sig, cfg)
    row = res.equity_curve.iloc[3]  # fill bar, still open
    assert "balance" in res.equity_curve.columns
    assert "unrealized" in res.equity_curve.columns
    assert row["equity"] == pytest.approx(row["balance"] + row["unrealized"])


def test_daily_loss_circuit_breaker():
    risk = RiskEngine(
        risk_fraction_per_trade=0.01,
        max_risk_fraction_per_trade=0.01,
        max_aggregate_exposure_units=1e9,
        max_simultaneous_positions=1,
        max_daily_loss_fraction=0.02,
        max_drawdown_fraction=0.99,
        initial_equity=10_000,
    )
    ts = datetime(2020, 1, 6, 8, tzinfo=timezone.utc)
    risk.update_equity(10_000, ts)
    risk.update_equity(9_700, ts)  # -3%
    d = risk.evaluate(
        equity=9_700,
        ts=ts,
        intended_units=1000,
        open_positions=0,
        current_exposure_units=0,
        entry_price=1.1,
        stop_price=1.09,
    )
    assert d.allowed is False
    assert "daily loss" in d.reason


def test_max_drawdown_breaker_still_works():
    risk = RiskEngine(
        risk_fraction_per_trade=0.01,
        max_risk_fraction_per_trade=0.01,
        max_aggregate_exposure_units=1e9,
        max_simultaneous_positions=1,
        max_daily_loss_fraction=0.99,
        max_drawdown_fraction=0.05,
        initial_equity=10_000,
    )
    ts = datetime(2020, 1, 6, tzinfo=timezone.utc)
    risk.update_equity(10_000, ts)
    risk.update_equity(9_400, ts)
    assert risk.halted


def test_chronological_split_no_shuffle():
    ts = pd.date_range("2020-01-06", periods=100, freq="h", tz="UTC")
    df = bars_from_rows(
        [{"timestamp": t, "open": 1.1, "high": 1.11, "low": 1.09, "close": 1.1} for t in ts]
    )
    splits = chronological_splits(df, fractions=(0.6, 0.2, 0.2), warmup_bars=10)
    assert [s.name for s in splits] == ["development", "validation", "holdout"]
    # later split trade_start after earlier
    assert splits[0].trade_start < splits[1].trade_start < splits[2].trade_start
    # frames stay sorted
    for s in splits:
        assert s.frame["timestamp"].is_monotonic_increasing


def test_warmup_blocks_trades_before_trade_start():
    ts = pd.date_range("2020-01-06", periods=80, freq="h", tz="UTC")
    close = 1.1
    rows = []
    for i, t in enumerate(ts):
        close = close + (0.0003 if i % 7 == 0 else -0.0001)
        rows.append(
            {
                "timestamp": t,
                "open": close,
                "high": close + 0.0004,
                "low": close - 0.0004,
                "close": close,
            }
        )
    df = bars_from_rows(rows)
    cfg = default_config()
    cfg["execution"]["trade_start"] = str(ts[50])
    cfg["account"]["initial_equity"] = 10_000
    strat = EmaTrendStrategy()
    eng = BacktestEngine(cfg, strat, make_risk(cfg))
    res = eng.run(df)
    if res.trades is not None and not res.trades.empty:
        assert pd.to_datetime(res.trades["entry_time"], utc=True).min() >= pd.Timestamp(ts[50])


def test_missing_data_detection_and_weekend():
    ts = [
        pd.Timestamp("2020-01-03 21:00", tz="UTC"),  # Friday
        pd.Timestamp("2020-01-05 22:00", tz="UTC"),  # Sunday — weekend
        pd.Timestamp("2020-01-06 00:00", tz="UTC"),
        pd.Timestamp("2020-01-06 06:00", tz="UTC"),  # unexpected 6h hole
    ]
    rows = []
    px = 1.1
    for t in ts:
        rows.append({"timestamp": t, "open": px, "high": px + 0.0002, "low": px - 0.0002, "close": px})
    df = bars_from_rows(rows)
    audit = audit_ohlc(df, source="test")
    assert audit["unexpected_missing_gap_count"] >= 1
    assert expected_fx_weekend(ts[0], ts[1])
    assert audit["invented_fill_candles"] == 0
