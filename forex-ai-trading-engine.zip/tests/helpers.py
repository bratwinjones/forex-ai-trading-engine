from __future__ import annotations

import pandas as pd

from src.backtest.engine import BacktestEngine
from src.risk.engine import RiskEngine
from src.strategy.base import Signal, Strategy


def bars_from_rows(rows: list[dict]) -> pd.DataFrame:
    df = pd.DataFrame(rows)
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True)
    return df


def default_config(**over):
    cfg = {
        "account": {"initial_equity": 10_000.0, "currency": "USD"},
        "costs": {
            "spread": 0.0002,
            "slippage": 0.0001,
            "commission_per_unit": 0.0,
            "commission_per_trade": 0.0,
        },
        "execution": {"fill_on": "next_open", "sl_tp_ambiguity": "conservative"},
        "risk": {
            "risk_fraction_per_trade": 0.01,
            "max_risk_fraction_per_trade": 0.01,
            "max_aggregate_exposure_units": 1_000_000,
            "max_simultaneous_positions": 1,
            "max_daily_loss_fraction": 0.5,
            "max_drawdown_fraction": 0.5,
        },
        "strategy": {},
    }
    for k, v in over.items():
        if isinstance(v, dict) and k in cfg:
            cfg[k] = {**cfg[k], **v}
        else:
            cfg[k] = v
    return cfg


class ScriptedStrategy(Strategy):
    """Emits a predetermined signal on a given bar index (0-based, after that bar closes)."""

    name = "scripted"

    def __init__(self, emit_at: int, signal: Signal):
        self.emit_at = emit_at
        self.signal = signal
        self.calls = []

    def on_bar(self, history: pd.DataFrame) -> Signal:
        i = len(history) - 1
        self.calls.append(float(history["close"].iloc[-1]))
        if i == self.emit_at:
            return self.signal
        return Signal(side="flat")


def make_risk(cfg, initial=None):
    r = cfg["risk"]
    return RiskEngine(
        risk_fraction_per_trade=r["risk_fraction_per_trade"],
        max_risk_fraction_per_trade=r["max_risk_fraction_per_trade"],
        max_aggregate_exposure_units=r["max_aggregate_exposure_units"],
        max_simultaneous_positions=r["max_simultaneous_positions"],
        max_daily_loss_fraction=r["max_daily_loss_fraction"],
        max_drawdown_fraction=r["max_drawdown_fraction"],
        initial_equity=initial or cfg["account"]["initial_equity"],
    )


def run_scripted(df, emit_at, signal, cfg=None, **risk_over):
    cfg = cfg or default_config()
    if risk_over:
        cfg["risk"] = {**cfg["risk"], **risk_over}
    strat = ScriptedStrategy(emit_at, signal)
    eng = BacktestEngine(cfg, strat, make_risk(cfg))
    return eng.run(df), strat
