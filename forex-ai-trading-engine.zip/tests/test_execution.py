"""Infrastructure tests on synthetic bars. Not a profitability claim."""

import pandas as pd

from src.strategy.base import Signal
from tests.helpers import bars_from_rows, default_config, run_scripted


def ladder(n=8, start="2020-01-01", o=1.10):
    rows = []
    ts = pd.date_range(start, periods=n, freq="h", tz="UTC")
    px = o
    for i, t in enumerate(ts):
        rows.append(
            {
                "timestamp": t,
                "open": px,
                "high": px + 0.0005,
                "low": px - 0.0005,
                "close": px + 0.0001,
            }
        )
        px += 0.0001
    return bars_from_rows(rows)


def test_no_lookahead_fill_is_next_open():
    df = ladder(6, o=1.2000)
    # Signal on bar 1 close -> fill at bar 2 OPEN, not bar 1 close/high.
    sig = Signal(side="long", stop_distance=0.0100, target_distance=0.0500, note="test")
    result, strat = run_scripted(df, emit_at=1, signal=sig)
    entries = [f for f in result.fills if f.action == "enter"]
    assert len(entries) == 1
    assert entries[0].bar == 2
    open2 = float(df.iloc[2]["open"])
    cfg = default_config()
    ask = open2 + cfg["costs"]["spread"] / 2 + cfg["costs"]["slippage"]
    assert abs(entries[0].price - ask) < 1e-12
    # Strategy never saw bar 2 close when it signaled.
    assert strat.calls[1] == float(df.iloc[1]["close"])


def test_spread_long_pays_ask():
    df = ladder(5, o=2.0000)
    sig = Signal(side="long", stop_distance=0.01, target_distance=0.05)
    result, _ = run_scripted(df, emit_at=0, signal=sig)
    entry = next(f for f in result.fills if f.action == "enter")
    mid = float(df.iloc[1]["open"])
    assert entry.price > mid


def test_stop_loss_long():
    # After entry, a bar that trades through stop but not target.
    rows = []
    ts = pd.date_range("2020-01-01", periods=5, freq="h", tz="UTC")
    prices = [
        (1.1000, 1.1005, 1.0995, 1.1002),
        (1.1002, 1.1008, 1.0998, 1.1004),
        (1.1004, 1.1010, 1.0999, 1.1005),  # signal here idx 2
        (1.1005, 1.1010, 1.1000, 1.1006),  # fill at open 1.1005
        (1.1006, 1.1007, 1.0800, 1.0900),  # SL
    ]
    for t, (o, h, l, c) in zip(ts, prices):
        rows.append({"timestamp": t, "open": o, "high": h, "low": l, "close": c})
    df = bars_from_rows(rows)
    sig = Signal(side="long", stop_distance=0.0050, target_distance=0.0500)
    result, _ = run_scripted(df, emit_at=2, signal=sig)
    exits = [f for f in result.fills if f.action == "exit"]
    assert exits and exits[0].reason == "stop_loss"


def test_take_profit_long():
    ts = pd.date_range("2020-01-01", periods=5, freq="h", tz="UTC")
    prices = [
        (1.10, 1.101, 1.099, 1.100),
        (1.10, 1.101, 1.099, 1.100),
        (1.10, 1.101, 1.099, 1.100),
        (1.10, 1.101, 1.099, 1.100),  # fill
        (1.10, 1.20, 1.099, 1.15),  # TP
    ]
    rows = [
        {"timestamp": t, "open": o, "high": h, "low": l, "close": c}
        for t, (o, h, l, c) in zip(ts, prices)
    ]
    df = bars_from_rows(rows)
    sig = Signal(side="long", stop_distance=0.05, target_distance=0.02)
    result, _ = run_scripted(df, emit_at=2, signal=sig)
    exits = [f for f in result.fills if f.action == "exit"]
    assert exits and exits[0].reason == "take_profit"


def test_ambiguous_sl_tp_uses_stop():
    ts = pd.date_range("2020-01-01", periods=5, freq="h", tz="UTC")
    prices = [
        (1.10, 1.101, 1.099, 1.100),
        (1.10, 1.101, 1.099, 1.100),
        (1.10, 1.101, 1.099, 1.100),
        (1.10, 1.101, 1.099, 1.100),
        (1.10, 1.30, 0.90, 1.10),  # both SL and TP inside range
    ]
    rows = [
        {"timestamp": t, "open": o, "high": h, "low": l, "close": c}
        for t, (o, h, l, c) in zip(ts, prices)
    ]
    df = bars_from_rows(rows)
    sig = Signal(side="long", stop_distance=0.02, target_distance=0.02)
    result, _ = run_scripted(df, emit_at=2, signal=sig)
    exits = [f for f in result.fills if f.action == "exit"]
    assert exits
    assert "conservative" in exits[0].reason or exits[0].reason == "stop_loss"
    # Must not take TP in ambiguity.
    assert exits[0].reason != "take_profit"
    entry = next(f for f in result.fills if f.action == "enter")
    assert exits[0].price <= entry.price
