from datetime import datetime, timezone

from src.risk.engine import RiskEngine
from src.strategy.base import Signal
from tests.helpers import bars_from_rows, default_config, run_scripted
import pandas as pd


def test_position_size_matches_equity_fraction():
    risk = RiskEngine(
        risk_fraction_per_trade=0.01,
        max_risk_fraction_per_trade=0.01,
        max_aggregate_exposure_units=1e9,
        max_simultaneous_positions=1,
        max_daily_loss_fraction=0.5,
        max_drawdown_fraction=0.5,
        initial_equity=10_000,
    )
    units = risk.size_from_stop(equity=10_000, entry_price=1.20, stop_price=1.19)
    # 1% of 10k = 100 USD risk, stop 0.01 -> 10_000 units
    assert abs(units - 10_000) < 1e-6


def test_drawdown_circuit_breaker_blocks_new_entries():
    risk = RiskEngine(
        risk_fraction_per_trade=0.01,
        max_risk_fraction_per_trade=0.01,
        max_aggregate_exposure_units=1e9,
        max_simultaneous_positions=1,
        max_daily_loss_fraction=0.99,
        max_drawdown_fraction=0.05,
        initial_equity=10_000,
    )
    ts = datetime(2020, 1, 1, tzinfo=timezone.utc)
    risk.update_equity(10_000, ts)
    risk.update_equity(9_000, ts)  # 10% DD > 5%
    d = risk.evaluate(
        equity=9_000,
        ts=ts,
        intended_units=1000,
        open_positions=0,
        current_exposure_units=0,
        entry_price=1.1,
        stop_price=1.09,
    )
    assert d.allowed is False
    assert "drawdown" in d.reason


def test_max_simultaneous_positions():
    ts = pd.date_range("2020-01-01", periods=4, freq="h", tz="UTC")
    rows = [
        {"timestamp": t, "open": 1.1, "high": 1.11, "low": 1.09, "close": 1.1} for t in ts
    ]
    df = bars_from_rows(rows)
    sig = Signal(side="long", stop_distance=0.01, target_distance=0.02)
    result, _ = run_scripted(df, emit_at=0, signal=sig, max_simultaneous_positions=0)
    assert not any(f.action == "enter" for f in result.fills)
