# fx-agent — Forex research / backtesting (no live trading)

Experimental Forex **research** system. It does **not** place real, demo, or external broker orders. There is **no live trading functionality**.

**Current phase: 2** (data-quality audit, accounting fixes, chronological 60/20/20 splits). Phase 1 built the bar-by-bar engine. **REAL HISTORICAL BACKTEST PENDING** (bundled CSV is synthetic).

Initial market: **EUR/USD**, **1-hour** bars, historical simulation only.

There is **no LLM** generating BUY/SELL decisions. The only strategy is a fixed EMA/ATR rule used to exercise the plumbing.

**Passing tests or a synthetic run is not evidence of trading profitability.**

## Installation

Python 3.13+. From this directory:

```bash
python -m pip install pandas numpy matplotlib PyYAML pytest
# PYTHONPATH=. required so `src` imports resolve
```

`requirements.txt` lists the expected stack (often already present in the Arena sandbox).

## Running tests

```bash
cd /path/to/fx-agent
PYTHONPATH=. python -m pytest tests -q
```

## Running a backtest

```bash
PYTHONPATH=. python -m src.run --config config/default.yaml --out reports
```

Writes quality + split reports. Default data is **synthetic**. Point `--csv` at a genuine H1 file when you have one.

## Known limitations

- No broker connection; `src/paper/broker.py` raises if you try to place orders.
- No 5-year genuine EUR/USD history in this repo.
- Costs in `config/default.yaml` are research **assumptions**, not broker quotes.
- Sandbox is not a 24/5 VPS. Do not treat results as live P&amp;L.

## No live trading

Do not connect OANDA/MT5/IB from this codebase until a later, explicit CEO decision. Martingale, grid, averaging-down, and LLM BUY/SELL are out of scope.

## Architecture

```
config/default.yaml     parameters, costs (assumptions), risk limits
data/                   local CSV only (no Yahoo/broker download)
src/ingest/             CSV load + strict OHLC validation
src/strategy/           bar-close signals from completed history
src/risk/               sizing + circuit breakers (cannot be bypassed)
src/backtest/           bar-by-bar engine, ledger, reports
src/paper/              stub that refuses external orders
tests/                  synthetic-bar unit tests
reports/                equity curve + ledger after a run
```

Flow: `CSV → validate → for each bar: fill pending @ next open → SL/TP on range → mark equity → strategy(history[:i]) → maybe queue next-bar order`.

## How signals become simulated orders

1. Strategy sees **only bars that have already closed** (`history` through the current index).
2. If it returns long/short with stop/target distances, the engine **queues** an order.
3. The order is **not** filled on that bar. Default `fill_on: next_open`.
4. `RiskEngine.evaluate` must allow the trade; size is **not** taken from the strategy.
5. Fill price is **ask** (long) or **bid** (short) at the next bar’s **open**, plus slippage.

## Execution timing

| Event | When |
|---|---|
| Indicator / signal | Close of bar `i` |
| Entry fill | Open of bar `i+1` (spread + slippage) |
| SL / TP | High/low of bars **after** the entry bar |

## Position sizing

Fixed fraction of **current cash/equity at risk** to the stop:

`units = risk_fraction * equity / |entry - stop|`

Capped by `max_risk_fraction_per_trade`, `max_aggregate_exposure_units`, `max_simultaneous_positions`. Daily-loss and drawdown **circuit breakers** halt new entries.

## Spread / slippage model (assumptions)

Configured in `config/default.yaml` under `costs`. These are **research assumptions**, not live broker quotes.

- Mid = OHLC price in the file  
- `ask = mid + spread/2 + slippage`  
- `bid = mid - spread/2 - slippage`  
- Optional commission fields default to 0  

Default spread `0.00015` (~1.5 pips) and slippage `0.00002` are conservative placeholders.

## SL/TP ambiguity policy

On a single OHLC bar, path is unknown. If **both** stop and target lie inside `[low, high]`:

**`sl_tp_ambiguity: conservative`** — assume **stop-loss** was hit. Do **not** take the profitable outcome.

Phase 1 does not implement optimistic or random tie-breaks.

## How to supply a historical CSV

1. Put a file under `data/` (see `data/README.md`).  
2. Columns: `timestamp,open,high,low,close` (optional `volume,spread`).  
3. UTC timestamps, chronological, unique, valid OHLC.  
4. Point `data.csv_path` in config, or `python -m src.run --csv /path/to.csv`.

Invalid data is **rejected** with a `ValidationError`. Nothing is silently “fixed.”

If you do not have genuine EUR/USD history, use the bundled **synthetic** CSV. A genuine historical backtest then **remains pending**.

## How to run tests

From `/home/user/fx-agent`:

```bash
PYTHONPATH=. python -m pytest tests -q
```

Tests use **tiny synthetic OHLC**. They check plumbing (look-ahead, spread, SL/TP, ambiguity, risk, validation). They do **not** show that EMA 20/50 is profitable.

## How to run a backtest

```bash
cd /home/user/fx-agent
PYTHONPATH=. python -m src.run --config config/default.yaml --out reports
```

Writes `reports/performance.md`, `reports/trade_ledger.csv`, `reports/equity_curve.csv`, `reports/equity_curve.png`.

## Baseline strategy (unoptimized)

- Fast EMA 20 / slow EMA 50 cross  
- ATR 14; stop 1.5×ATR; target 2.0×ATR  
- Parameters live in config; **do not optimize in Phase 1**

## Explicitly out of scope (Phase 1)

- Broker, MT5, demo/live orders  
- Martingale, grid, averaging down  
- Leverage optimization, ML, LLM signals  
- Downloading random web data to chase a green equity curve  
