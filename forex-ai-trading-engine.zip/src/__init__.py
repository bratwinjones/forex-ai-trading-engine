"""Phase 1 FX research/backtesting package. No live or broker orders."""

__version__ = "0.1.0"
