from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Optional

import pandas as pd

Side = Literal["long", "short", "flat"]


@dataclass(frozen=True)
class Signal:
    side: Side  # desired position after this bar close
    stop_distance: Optional[float] = None
    target_distance: Optional[float] = None
    note: str = ""


class Strategy:
    name = "base"

    def on_bar(self, history: pd.DataFrame) -> Signal:
        """history includes the just-completed bar and all prior bars only."""
        return Signal(side="flat")
