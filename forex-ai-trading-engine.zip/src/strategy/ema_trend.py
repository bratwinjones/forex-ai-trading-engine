from __future__ import annotations

import numpy as np
import pandas as pd

from .base import Signal, Strategy


def ema(series: pd.Series, span: int) -> pd.Series:
    return series.ewm(span=span, adjust=False).mean()


def atr(df: pd.DataFrame, period: int) -> pd.Series:
    prev_close = df["close"].shift(1)
    tr = pd.concat(
        [
            df["high"] - df["low"],
            (df["high"] - prev_close).abs(),
            (df["low"] - prev_close).abs(),
        ],
        axis=1,
    ).max(axis=1)
    return tr.ewm(span=period, adjust=False).mean()


class EmaTrendStrategy(Strategy):
    name = "ema_trend"

    def __init__(
        self,
        fast_ema: int = 20,
        slow_ema: int = 50,
        atr_period: int = 14,
        stop_atr_mult: float = 1.5,
        target_atr_mult: float = 2.0,
    ):
        self.fast_ema = fast_ema
        self.slow_ema = slow_ema
        self.atr_period = atr_period
        self.stop_atr_mult = stop_atr_mult
        self.target_atr_mult = target_atr_mult

    def on_bar(self, history: pd.DataFrame) -> Signal:
        need = max(self.slow_ema, self.atr_period) + 2
        if len(history) < need:
            return Signal(side="flat", note="warmup")

        close = history["close"]
        fast = ema(close, self.fast_ema)
        slow = ema(close, self.slow_ema)
        a = atr(history, self.atr_period)
        i = len(history) - 1
        if np.isnan(fast.iloc[i]) or np.isnan(slow.iloc[i]) or np.isnan(a.iloc[i]):
            return Signal(side="flat", note="nan")
        if np.isnan(fast.iloc[i - 1]) or np.isnan(slow.iloc[i - 1]):
            return Signal(side="flat", note="nan")

        cross_up = fast.iloc[i - 1] <= slow.iloc[i - 1] and fast.iloc[i] > slow.iloc[i]
        cross_dn = fast.iloc[i - 1] >= slow.iloc[i - 1] and fast.iloc[i] < slow.iloc[i]
        stop_d = float(a.iloc[i] * self.stop_atr_mult)
        tgt_d = float(a.iloc[i] * self.target_atr_mult)
        if stop_d <= 0:
            return Signal(side="flat", note="bad atr")
        if cross_up:
            return Signal(side="long", stop_distance=stop_d, target_distance=tgt_d, note="ema cross up")
        if cross_dn:
            return Signal(side="short", stop_distance=stop_d, target_distance=tgt_d, note="ema cross down")
        return Signal(side="flat", note="no cross")
