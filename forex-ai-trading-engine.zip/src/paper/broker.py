"""In-process paper broker stub.

Phase 1 does not connect to any external broker and does not place demo/live
orders. This module exists so later phases can swap a fill model without
changing strategy code.
"""

from __future__ import annotations


class PaperBroker:
    def __init__(self):
        self.enabled = False

    def place_order(self, *args, **kwargs):
        raise RuntimeError(
            "Phase 1: external/demo/live orders are disabled. Use the backtester."
        )
