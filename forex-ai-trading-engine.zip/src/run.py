"""Run Phase 2 research backtests. No broker I/O."""

from __future__ import annotations

import argparse
import copy
from pathlib import Path

import yaml

from src.backtest.analytics import beginner_report, write_split_reports
from src.backtest.engine import BacktestEngine
from src.backtest.report import write_reports
from src.backtest.splits import chronological_splits
from src.ingest.loader import load_ohlc_csv
from src.ingest.quality import audit_ohlc, write_quality_report
from src.risk.engine import RiskEngine
from src.strategy.ema_trend import EmaTrendStrategy


def load_config(path: Path) -> dict:
    with path.open() as f:
        return yaml.safe_load(f)


def build(config: dict) -> BacktestEngine:
    s = config["strategy"]
    strategy = EmaTrendStrategy(
        fast_ema=int(s["fast_ema"]),
        slow_ema=int(s["slow_ema"]),
        atr_period=int(s["atr_period"]),
        stop_atr_mult=float(s["stop_atr_mult"]),
        target_atr_mult=float(s["target_atr_mult"]),
    )
    r = config["risk"]
    risk = RiskEngine(
        risk_fraction_per_trade=float(r["risk_fraction_per_trade"]),
        max_risk_fraction_per_trade=float(r["max_risk_fraction_per_trade"]),
        max_aggregate_exposure_units=float(r["max_aggregate_exposure_units"]),
        max_simultaneous_positions=int(r["max_simultaneous_positions"]),
        max_daily_loss_fraction=float(r["max_daily_loss_fraction"]),
        max_drawdown_fraction=float(r["max_drawdown_fraction"]),
        initial_equity=float(config["account"]["initial_equity"]),
    )
    return BacktestEngine(config, strategy, risk)


def main(argv=None) -> int:
    root = Path(__file__).resolve().parents[1]
    p = argparse.ArgumentParser(description="Phase 2 FX research backtest (no broker)")
    p.add_argument("--config", default=str(root / "config" / "default.yaml"))
    p.add_argument("--csv", default=None)
    p.add_argument("--out", default=str(root / "reports"))
    p.add_argument("--source-label", default=None)
    args = p.parse_args(argv)
    config = load_config(Path(args.config))
    csv_path = Path(args.csv) if args.csv else root / config["data"]["csv_path"]
    bars = load_ohlc_csv(csv_path, config["data"].get("timestamp_column", "timestamp"))
    genuine = bool(config["data"].get("genuine_historical", False))
    source = args.source_label or (
        "user CSV (genuine flag on)" if genuine else "synthetic_eurusd_h1.csv (NOT genuine EUR/USD)"
    )

    audit = audit_ohlc(bars, source=source, csv_path=str(csv_path))
    audit["limitations"] = [
        "REAL HISTORICAL BACKTEST PENDING" if not genuine else "User-supplied history; still not live trading.",
        "No candles were invented to fill gaps.",
    ]
    out = Path(args.out)
    write_quality_report(audit, out / "data_quality.md")

    # Full-sample plumbing run (same unoptimized EMA).
    full_engine = build(config)
    full = full_engine.run(bars)
    write_reports(full, out / "full_sample")

    split_metrics = {}
    for spl in chronological_splits(bars, fractions=(0.6, 0.2, 0.2), warmup_bars=60):
        cfg = copy.deepcopy(config)
        cfg.setdefault("execution", {})
        cfg["execution"]["trade_start"] = spl.trade_start.isoformat()
        eng = build(cfg)
        res = eng.run(spl.frame)
        res.split_name = spl.name
        # Drop trades that entered before trade_start (should already be blocked).
        if res.trades is not None and not res.trades.empty:
            mask = pd_ge(res.trades["entry_time"], spl.trade_start)
            res.trades = res.trades.loc[mask].reset_index(drop=True)
        split_metrics[spl.name] = write_split_reports(res, out / "splits", spl.name)

    (out / "beginner_report.md").write_text(
        beginner_report(split_metrics, genuine_data=genuine), encoding="utf-8"
    )

    print("Phase 2 research run complete. NOT live trading.")
    print(f"CSV: {csv_path}")
    print(f"Source: {source}")
    if not genuine:
        print("REAL HISTORICAL BACKTEST PENDING")
    for k, m in split_metrics.items():
        print(f"  {k}: trades={m.get('total_trades')} return={m.get('total_return')}")
    return 0


def pd_ge(series, ts):
    import pandas as pd

    ts = pd.Timestamp(ts)
    if ts.tzinfo is None:
        ts = ts.tz_localize("UTC")
    else:
        ts = ts.tz_convert("UTC")
    return pd.to_datetime(series, utc=True) >= ts


if __name__ == "__main__":
    raise SystemExit(main())
