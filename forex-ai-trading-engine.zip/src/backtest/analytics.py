from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from .engine import BacktestResult
from .report import performance_report, write_reports


def pip_value_usd(units_eur: float, pip: float = 0.0001) -> float:
    """USD per pip for a EURUSD position of `units_eur` base units."""
    return units_eur * pip


def directional_pnl_usd(units_eur: float, price_change: float, side: str = "long") -> float:
    sign = 1.0 if side == "long" else -1.0
    return units_eur * price_change * sign


def extended_metrics(result: BacktestResult) -> dict:
    base = performance_report(result)
    trades = result.trades
    eq = result.equity_curve
    hours = 0.0
    if len(eq) >= 2:
        dt = pd.to_datetime(eq["timestamp"], utc=True)
        hours = (dt.iloc[-1] - dt.iloc[0]).total_seconds() / 3600.0
    years = hours / (24.0 * 365.25) if hours > 0 else float("nan")
    tot = base["total_return"]
    if years and years > 1 / 12 and tot > -0.999:
        ann = (1 + tot) ** (1 / years) - 1
    else:
        ann = float("nan")
        base["annualized_return_note"] = "not meaningful (short window or tiny sample)"
    base["annualized_return"] = ann

    if trades is None or trades.empty:
        base.update(
            {
                "average_holding_hours": float("nan"),
                "long_trades": 0,
                "short_trades": 0,
                "long_net_pnl": 0.0,
                "short_net_pnl": 0.0,
                "gross_pnl_sum": 0.0,
                "net_pnl_sum": 0.0,
                "small_sample": True,
            }
        )
        return base

    t = trades.copy()
    t["entry_time"] = pd.to_datetime(t["entry_time"], utc=True)
    t["exit_time"] = pd.to_datetime(t["exit_time"], utc=True)
    hold = (t["exit_time"] - t["entry_time"]).dt.total_seconds() / 3600.0
    base["average_holding_hours"] = float(hold.mean())
    long = t[t["side"] == "long"]
    short = t[t["side"] == "short"]
    base["long_trades"] = int(len(long))
    base["short_trades"] = int(len(short))
    base["long_net_pnl"] = float(long["pnl"].sum()) if len(long) else 0.0
    base["short_net_pnl"] = float(short["pnl"].sum()) if len(short) else 0.0
    base["gross_pnl_sum"] = float(t["gross_pnl"].sum()) if "gross_pnl" in t else float("nan")
    base["net_pnl_sum"] = float(t["pnl"].sum())
    base["small_sample"] = len(t) < 30

    eq2 = eq.copy()
    eq2["timestamp"] = pd.to_datetime(eq2["timestamp"], utc=True)
    eq2["month"] = eq2["timestamp"].dt.to_period("M")
    monthly = []
    for period, g in eq2.groupby("month"):
        e0, e1 = float(g["equity"].iloc[0]), float(g["equity"].iloc[-1])
        monthly.append({"month": str(period), "return": (e1 - e0) / e0 if e0 else 0.0})
    base["monthly_returns"] = monthly
    return base


def write_split_reports(result: BacktestResult, out_dir: str | Path, name: str) -> dict:
    out = Path(out_dir) / name
    metrics = write_reports(result, out)
    ext = extended_metrics(result)
    extra = [
        "",
        "## Extended (Phase 2)",
        f"- **split**: {name}",
        f"- **annualized_return**: {ext.get('annualized_return')}",
        f"- **gross_pnl_sum**: {ext.get('gross_pnl_sum')}",
        f"- **net_pnl_sum**: {ext.get('net_pnl_sum')}",
        f"- **average_holding_hours**: {ext.get('average_holding_hours')}",
        f"- **long_trades**: {ext.get('long_trades')} pnl={ext.get('long_net_pnl')}",
        f"- **short_trades**: {ext.get('short_trades')} pnl={ext.get('short_net_pnl')}",
        f"- **small_sample**: {ext.get('small_sample')}",
        "",
        "Gross vs net: net includes modeled commissions; spread/slippage is already in fill prices.",
        "Do not claim statistical significance from these figures.",
        "",
        "### Monthly returns",
    ]
    for m in ext.get("monthly_returns") or []:
        extra.append(f"- {m['month']}: {m['return']:.4%}")
    p = out / "performance.md"
    p.write_text(p.read_text(encoding="utf-8") + "\n".join(extra), encoding="utf-8")
    return ext


def beginner_report(split_metrics: dict[str, dict], *, genuine_data: bool) -> str:
    lines = [
        "# Beginner explanation",
        "",
        "**HISTORICAL BACKTEST ONLY — NOT LIVE TRADING RESULTS.**",
        "",
        "This robot is a **rules checklist**, not a fortune teller. It watches two moving averages (EMA 20 and EMA 50).",
        "When the fast average crosses above the slow one, it **buys** EUR/USD (long).",
        "When it crosses below, it **sells** EUR/USD (short).",
        "It tries to cut a loss at 1.5× ATR and take a profit at 2.0× ATR. Those numbers were **not** optimized.",
        "",
        "Money at risk per trade is a small slice of the account (default 0.5%) measured to the stop.",
        "A stop is **not** a promise: prices can jump over it (a gap).",
        "",
    ]
    if not genuine_data:
        lines += [
            "## REAL HISTORICAL BACKTEST PENDING",
            "",
            "The numbers below used **synthetic** (fake) candles so the software could be tested.",
            "They are **not** EUR/USD market results. Do not use them to decide to trade live.",
            "",
        ]
    for name in ("development", "validation", "holdout"):
        m = split_metrics.get(name)
        if not m:
            lines += [f"## {name}", "No run.", ""]
            continue
        n = m.get("total_trades", 0)
        small = m.get("small_sample", True)
        lines += [
            f"## {name} period",
            f"- Trades: {n}" + (" (**small sample — do not trust the win rate**)" if small else ""),
            f"- Start equity: {m.get('starting_equity')}",
            f"- End equity: {m.get('ending_equity')}",
            f"- Total return: {m.get('total_return')}",
            f"- Max drawdown: {m.get('max_drawdown_money')} ({m.get('max_drawdown_pct')})",
            f"- Win rate: {m.get('win_rate')}",
            f"- Profit factor: {m.get('profit_factor')}",
            f"- Net P&L: {m.get('net_pnl_sum')}  |  Gross P&L: {m.get('gross_pnl_sum')}",
            f"- Modeled extra costs field: {m.get('costs_paid')}",
            "",
        ]
    # consistency
    rets = [split_metrics[k]["total_return"] for k in split_metrics if "total_return" in split_metrics[k]]
    consistent = len(rets) >= 2 and all((r > 0) == (rets[0] > 0) for r in rets)
    lines += [
        "## Were results consistent?",
        "Yes, same sign across splits." if consistent and rets else "No / not enough evidence — periods disagree or sample is tiny.",
        "",
        "## Did costs change the story?",
        "Compare gross vs net in each split. Spread is already inside fill prices, so even 'gross' is not a zero-cost fantasy.",
        "",
        "## Should we keep testing?",
        "Keep testing **infrastructure and risk**, and only then a real broker CSV. A green synthetic or single-period result does **not** mean the strategy is profitable.",
        "Do not describe this system as profitable because one slice of history (or fake data) went up.",
        "",
        "HISTORICAL BACKTEST ONLY — NOT LIVE TRADING RESULTS.",
        "",
    ]
    return "\n".join(lines)
