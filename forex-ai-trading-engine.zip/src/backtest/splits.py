"""Chronological 60/20/20 splits. Never shuffle time."""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd


@dataclass
class Split:
    name: str
    frame: pd.DataFrame
    trade_start: pd.Timestamp
    warmup_bars: int


def chronological_splits(
    df: pd.DataFrame,
    *,
    fractions: tuple[float, float, float] = (0.6, 0.2, 0.2),
    warmup_bars: int = 60,
) -> list[Split]:
    if abs(sum(fractions) - 1.0) > 1e-9:
        raise ValueError("fractions must sum to 1")
    n = len(df)
    if n < 10:
        raise ValueError("not enough bars to split")
    n_dev = int(n * fractions[0])
    n_val = int(n * fractions[1])
    i0, i1, i2, i3 = 0, n_dev, n_dev + n_val, n
    names = ("development", "validation", "holdout")
    bounds = [(i0, i1), (i1, i2), (i2, i3)]
    out: list[Split] = []
    for name, (a, b) in zip(names, bounds):
        if b <= a:
            continue
        warm0 = max(0, a - warmup_bars)
        frame = df.iloc[warm0:b].reset_index(drop=True)
        trade_start = df.iloc[a]["timestamp"]
        out.append(Split(name=name, frame=frame, trade_start=pd.Timestamp(trade_start), warmup_bars=a - warm0))
    return out
