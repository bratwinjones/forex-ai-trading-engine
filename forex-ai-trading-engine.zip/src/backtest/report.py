from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from .engine import BacktestResult


def performance_report(result: BacktestResult) -> dict:
    trades = result.trades
    start = result.starting_equity
    end = result.ending_equity
    total_return = (end - start) / start if start else 0.0
    n = 0 if trades is None or trades.empty else len(trades)
    wins = losses = 0
    avg_win = avg_loss = 0.0
    pf = float("nan")
    exp = 0.0
    largest_win = largest_loss = 0.0
    consec_w = consec_l = 0
    costs = 0.0
    if n:
        pnl = trades["pnl"].astype(float)
        w = pnl[pnl > 0]
        l = pnl[pnl < 0]
        wins, losses = int(len(w)), int(len(l))
        avg_win = float(w.mean()) if len(w) else 0.0
        avg_loss = float(l.mean()) if len(l) else 0.0
        gp, gl = float(w.sum()) if len(w) else 0.0, float(-l.sum()) if len(l) else 0.0
        pf = gp / gl if gl > 0 else float("inf") if gp > 0 else float("nan")
        exp = float(pnl.mean())
        largest_win = float(pnl.max())
        largest_loss = float(pnl.min())
        consec_w = _max_streak(pnl > 0)
        consec_l = _max_streak(pnl < 0)
        costs = float(trades["costs"].sum()) if "costs" in trades.columns else 0.0

    eq = result.equity_curve["equity"].astype(float)
    peak = eq.cummax()
    dd = peak - eq
    max_dd = float(dd.max()) if len(dd) else 0.0
    max_dd_pct = float((dd / peak.replace(0, np.nan)).max()) if len(dd) else 0.0

    return {
        "starting_equity": start,
        "ending_equity": end,
        "total_return": total_return,
        "total_trades": n,
        "winning_trades": wins,
        "losing_trades": losses,
        "win_rate": (wins / n) if n else float("nan"),
        "average_win": avg_win,
        "average_loss": avg_loss,
        "profit_factor": pf,
        "expectancy_per_trade": exp,
        "max_drawdown_money": max_dd,
        "max_drawdown_pct": max_dd_pct,
        "largest_win": largest_win,
        "largest_loss": largest_loss,
        "consecutive_wins": consec_w,
        "consecutive_losses": consec_l,
        "costs_paid": costs,
        "notes": result.notes,
    }


def _max_streak(mask: pd.Series) -> int:
    best = cur = 0
    for v in mask.astype(bool):
        if v:
            cur += 1
            best = max(best, cur)
        else:
            cur = 0
    return best


def write_reports(result: BacktestResult, out_dir: str | Path) -> dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    metrics = performance_report(result)
    lines = ["# Backtest performance (infrastructure output, not proof of edge)", ""]
    for k, v in metrics.items():
        if k == "notes":
            continue
        lines.append(f"- **{k}**: {v}")
    lines += ["", "## Assumptions / notes"]
    for n in metrics.get("notes", []):
        lines.append(f"- {n}")
    lines.append("")
    lines.append(
        "Successful software tests or a synthetic-data run are **not** evidence of trading profitability."
    )
    (out / "performance.md").write_text("\n".join(lines), encoding="utf-8")
    if result.trades is not None:
        result.trades.to_csv(out / "trade_ledger.csv", index=False)
    result.equity_curve.to_csv(out / "equity_curve.csv", index=False)

    fig, ax = plt.subplots(figsize=(10, 4))
    ax.plot(result.equity_curve["timestamp"], result.equity_curve["equity"], color="#1e406f")
    ax.set_title("Equity curve (simulated)")
    ax.set_ylabel("Equity")
    ax.grid(True, alpha=0.3)
    fig.autofmt_xdate()
    fig.tight_layout()
    fig.savefig(out / "equity_curve.png", dpi=120)
    plt.close(fig)
    return metrics
