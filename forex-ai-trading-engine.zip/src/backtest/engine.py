"""Bar-by-bar backtester. Decisions use only completed history; fills on next bar."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal, Optional

import pandas as pd

from src.risk.engine import RiskEngine
from src.strategy.base import Signal, Strategy

Side = Literal["long", "short"]


@dataclass
class Position:
    side: Side
    units: float
    entry_price: float
    stop: float
    target: float
    entry_time: pd.Timestamp
    entry_bar: int


@dataclass
class Fill:
    time: pd.Timestamp
    bar: int
    side: str
    action: str
    units: float
    price: float
    reason: str
    cash_delta: float


@dataclass
class BacktestResult:
    bars: pd.DataFrame
    equity_curve: pd.DataFrame
    fills: list[Fill]
    trades: pd.DataFrame
    starting_equity: float
    ending_equity: float
    config: dict
    notes: list[str] = field(default_factory=list)
    split_name: str | None = None


class BacktestEngine:
    def __init__(self, config: dict, strategy: Strategy, risk: RiskEngine):
        self.config = config
        self.strategy = strategy
        self.risk = risk
        costs = config["costs"]
        self.spread = float(costs["spread"])
        self.slippage = float(costs["slippage"])
        self.commission_per_unit = float(costs.get("commission_per_unit", 0.0))
        self.commission_per_trade = float(costs.get("commission_per_trade", 0.0))
        self.fill_on = config["execution"]["fill_on"]
        self.ambiguity = config["execution"]["sl_tp_ambiguity"]
        if self.fill_on != "next_open":
            raise ValueError("Phase 1/2 only supports fill_on=next_open")
        if self.ambiguity != "conservative":
            raise ValueError("Phase 1/2 only supports sl_tp_ambiguity=conservative")
        self.initial = float(config["account"]["initial_equity"])
        self.trade_start = config.get("execution", {}).get("trade_start")
        # Round-trip modeled cost per unit (price units ≈ USD per EUR on EURUSD).
        self.extra_cost_per_unit = self.spread + 2.0 * self.slippage + self.commission_per_unit

    def _ask(self, mid: float) -> float:
        return mid + self.spread / 2.0 + self.slippage

    def _bid(self, mid: float) -> float:
        return mid - self.spread / 2.0 - self.slippage

    def _mark(self, pos: Optional[Position], mid: float) -> float:
        if pos is None:
            return 0.0
        if pos.side == "long":
            return pos.units * (self._bid(mid) - pos.entry_price)
        return pos.units * (pos.entry_price - self._ask(mid))

    def _allows_new_trades(self, ts) -> bool:
        if self.trade_start is None:
            return True
        return pd.Timestamp(ts) >= pd.Timestamp(self.trade_start)

    def run(self, bars: pd.DataFrame) -> BacktestResult:
        df = bars.reset_index(drop=True)
        cash = self.initial  # realized balance
        pos: Optional[Position] = None
        pending: Optional[Signal] = None
        fills: list[Fill] = []
        trade_rows: list[dict] = []
        eq_rows: list[dict] = []
        notes = [
            "fill_on=next_open: signal on bar i close fills at bar i+1 open (with spread/slippage).",
            "sl_tp_ambiguity=conservative: if both SL and TP lie inside a candle range, SL is assumed.",
            "Gap through stop: fill at the more adverse of stop vs bar OPEN (stop is not a max-loss guarantee).",
            "EURUSD USD PnL = units_EUR * price_change (pip = 0.0001; 10k units * 10 pips = $10 gross).",
            "spread/slippage values are configurable RESEARCH ASSUMPTIONS, not broker quotes.",
            "balance = realized cash; equity = balance + unrealized mark-to-bid/ask.",
        ]

        def exposure() -> float:
            return pos.units if pos else 0.0

        for i in range(len(df)):
            row = df.iloc[i]
            ts = row["timestamp"]
            o, h, l, c = float(row["open"]), float(row["high"]), float(row["low"]), float(row["close"])

            if pending is not None and pending.side in ("long", "short") and pos is None:
                if pending.side == "long":
                    px = self._ask(o)
                    stop = px - float(pending.stop_distance)
                    target = px + float(pending.target_distance)
                else:
                    px = self._bid(o)
                    stop = px + float(pending.stop_distance)
                    target = px - float(pending.target_distance)
                intended = 1e18
                decision = self.risk.evaluate(
                    equity=cash,
                    ts=pd.Timestamp(ts).to_pydatetime(),
                    intended_units=intended,
                    open_positions=1 if pos else 0,
                    current_exposure_units=exposure(),
                    entry_price=px,
                    stop_price=stop,
                    extra_cost_per_unit=self.extra_cost_per_unit,
                )
                if decision.allowed and decision.units > 0:
                    comm = self.commission_per_trade / 2.0 + self.commission_per_unit * decision.units
                    cash -= comm
                    pos = Position(
                        side=pending.side,
                        units=decision.units,
                        entry_price=px,
                        stop=stop,
                        target=target,
                        entry_time=ts,
                        entry_bar=i,
                    )
                    fills.append(
                        Fill(ts, i, pending.side, "enter", decision.units, px, pending.note, -comm)
                    )
                pending = None
            elif pending is not None:
                pending = None

            if pos is not None and i > pos.entry_bar:
                exit_px, reason = self._exit_from_bar(pos, o, h, l)
                if exit_px is not None:
                    cash, trade = self._close(pos, ts, i, exit_px, reason, cash)
                    fills.append(trade[0])
                    trade_rows.append(trade[1])
                    pos = None

            unreal = self._mark(pos, c)
            equity = cash + unreal
            self.risk.update_equity(equity, pd.Timestamp(ts).to_pydatetime())
            eq_rows.append(
                {
                    "timestamp": ts,
                    "balance": cash,
                    "cash": cash,
                    "unrealized": unreal,
                    "equity": equity,
                    "position": 0 if pos is None else (pos.units if pos.side == "long" else -pos.units),
                }
            )

            history = df.iloc[: i + 1]
            signal = self.strategy.on_bar(history)

            if (
                pos is None
                and self._allows_new_trades(ts)
                and not self.risk.halted
                and signal.side in ("long", "short")
                and signal.stop_distance
                and signal.target_distance
            ):
                pending = signal

        if pos is not None:
            last = df.iloc[-1]
            px = self._bid(float(last["close"])) if pos.side == "long" else self._ask(float(last["close"]))
            cash, trade = self._close(pos, last["timestamp"], len(df) - 1, px, "eod_flatten", cash)
            fills.append(trade[0])
            trade_rows.append(trade[1])
            pos = None
            if eq_rows:
                eq_rows[-1]["cash"] = cash
                eq_rows[-1]["balance"] = cash
                eq_rows[-1]["unrealized"] = 0.0
                eq_rows[-1]["equity"] = cash
                eq_rows[-1]["position"] = 0

        trades = pd.DataFrame(trade_rows)
        equity_curve = pd.DataFrame(eq_rows)
        ending = float(equity_curve["equity"].iloc[-1]) if len(equity_curve) else self.initial
        return BacktestResult(
            bars=df,
            equity_curve=equity_curve,
            fills=fills,
            trades=trades,
            starting_equity=self.initial,
            ending_equity=ending,
            config=self.config,
            notes=notes,
        )

    def _exit_from_bar(self, pos: Position, o: float, h: float, l: float):
        """Conservative SL/TP plus adverse gap at OPEN.

        A stop-loss is not a guaranteed maximum loss.
        """
        if pos.side == "long":
            gapped_sl = o < pos.stop
            gapped_tp = o > pos.target
            hit_sl = l <= pos.stop
            hit_tp = h >= pos.target
            if gapped_sl and gapped_tp:
                return o, "ambiguous_gap_conservative_open"
            if gapped_sl:
                return o, "stop_loss_gap"
            if hit_sl and hit_tp:
                return pos.stop, "ambiguous_sl_tp_conservative_sl"
            if hit_sl:
                return pos.stop, "stop_loss"
            if gapped_tp:
                # Open jumped through TP: fill TP, not a better fantasy price.
                return pos.target, "take_profit"
            if hit_tp:
                return pos.target, "take_profit"
        else:
            gapped_sl = o > pos.stop
            gapped_tp = o < pos.target
            hit_sl = h >= pos.stop
            hit_tp = l <= pos.target
            if gapped_sl and gapped_tp:
                return o, "ambiguous_gap_conservative_open"
            if gapped_sl:
                return o, "stop_loss_gap"
            if hit_sl and hit_tp:
                return pos.stop, "ambiguous_sl_tp_conservative_sl"
            if hit_sl:
                return pos.stop, "stop_loss"
            if gapped_tp:
                return pos.target, "take_profit"
            if hit_tp:
                return pos.target, "take_profit"
        return None, ""

    def _close(self, pos: Position, ts, bar: int, exit_px: float, reason: str, cash: float):
        if pos.side == "long":
            pnl = pos.units * (exit_px - pos.entry_price)
        else:
            pnl = pos.units * (pos.entry_price - exit_px)
        comm = self.commission_per_trade / 2.0 + self.commission_per_unit * pos.units
        cash += pnl - comm
        fill = Fill(ts, bar, pos.side, "exit", pos.units, exit_px, reason, pnl - comm)
        modeled_spread_slip = pos.units * (self.spread + 2 * self.slippage)
        trade = {
            "entry_time": pos.entry_time,
            "exit_time": ts,
            "side": pos.side,
            "units": pos.units,
            "entry_price": pos.entry_price,
            "exit_price": exit_px,
            "pnl": pnl - comm,
            "net_pnl": pnl - comm,
            "gross_pnl": pnl,
            "costs": comm + modeled_spread_slip,
            "reason": reason,
        }
        return cash, (fill, trade)
