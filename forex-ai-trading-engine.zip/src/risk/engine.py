"""Risk constraints that strategy code cannot bypass.

The backtester is the only place that submits intended orders, and it must
call RiskEngine.evaluate before any fill.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timezone


@dataclass(frozen=True)
class RiskDecision:
    allowed: bool
    units: float
    reason: str


class RiskEngine:
    def __init__(
        self,
        *,
        risk_fraction_per_trade: float,
        max_risk_fraction_per_trade: float,
        max_aggregate_exposure_units: float,
        max_simultaneous_positions: int,
        max_daily_loss_fraction: float,
        max_drawdown_fraction: float,
        initial_equity: float,
    ):
        if risk_fraction_per_trade <= 0 or max_risk_fraction_per_trade <= 0:
            raise ValueError("risk fractions must be positive")
        self.risk_fraction = min(risk_fraction_per_trade, max_risk_fraction_per_trade)
        self.max_risk_fraction = max_risk_fraction_per_trade
        self.max_aggregate_exposure_units = max_aggregate_exposure_units
        self.max_simultaneous_positions = max_simultaneous_positions
        self.max_daily_loss_fraction = max_daily_loss_fraction
        self.max_drawdown_fraction = max_drawdown_fraction
        self.initial_equity = initial_equity
        self.peak_equity = initial_equity
        self.day_start_equity = initial_equity
        self.current_day: date | None = None
        self.halted = False
        self.halt_reason = ""

    def update_equity(self, equity: float, ts: datetime) -> None:
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        d = ts.date()
        if self.current_day is None:
            self.current_day = d
            self.day_start_equity = equity
        elif d != self.current_day:
            self.current_day = d
            self.day_start_equity = equity
        self.peak_equity = max(self.peak_equity, equity)
        dd = (self.peak_equity - equity) / self.peak_equity if self.peak_equity else 0.0
        if dd >= self.max_drawdown_fraction:
            self.halted = True
            self.halt_reason = (
                f"drawdown circuit breaker: {dd:.2%} >= {self.max_drawdown_fraction:.2%}"
            )
        day_loss = (self.day_start_equity - equity) / self.day_start_equity if self.day_start_equity else 0.0
        if day_loss >= self.max_daily_loss_fraction:
            self.halted = True
            self.halt_reason = (
                f"max daily loss: {day_loss:.2%} >= {self.max_daily_loss_fraction:.2%}"
            )

    def size_from_stop(
        self,
        *,
        equity: float,
        entry_price: float,
        stop_price: float,
        extra_cost_per_unit: float = 0.0,
    ) -> float:
        """Units so that (stop_dist + extra costs) * units ~= risk_fraction * equity.

        extra_cost_per_unit should include modeled round-trip spread/slippage/commission
        in account currency per 1 unit of base. A stop is NOT a guaranteed max loss
        if the market gaps through the stop.
        """
        stop_dist = abs(entry_price - stop_price) + max(0.0, extra_cost_per_unit)
        if stop_dist <= 0 or equity <= 0:
            return 0.0
        risk_cash = self.risk_fraction * equity
        return risk_cash / stop_dist

    def evaluate(
        self,
        *,
        equity: float,
        ts: datetime,
        intended_units: float,
        open_positions: int,
        current_exposure_units: float,
        entry_price: float,
        stop_price: float,
        extra_cost_per_unit: float = 0.0,
    ) -> RiskDecision:
        self.update_equity(equity, ts)
        if self.halted:
            return RiskDecision(False, 0.0, self.halt_reason)

        if open_positions >= self.max_simultaneous_positions:
            return RiskDecision(False, 0.0, "max simultaneous positions")

        sized = self.size_from_stop(
            equity=equity,
            entry_price=entry_price,
            stop_price=stop_price,
            extra_cost_per_unit=extra_cost_per_unit,
        )
        units = min(abs(intended_units), sized) if intended_units else sized
        if units <= 0:
            return RiskDecision(False, 0.0, "zero size after risk calc")

        if current_exposure_units + units > self.max_aggregate_exposure_units:
            remaining = self.max_aggregate_exposure_units - current_exposure_units
            if remaining <= 0:
                return RiskDecision(False, 0.0, "max aggregate exposure")
            units = remaining

        stop_dist = abs(entry_price - stop_price) + max(0.0, extra_cost_per_unit)
        risk_cash = units * stop_dist
        if stop_dist > 0 and equity > 0 and risk_cash / equity > self.max_risk_fraction + 1e-12:
            units = (self.max_risk_fraction * equity) / stop_dist
            if units <= 0:
                return RiskDecision(False, 0.0, "max risk per trade")

        return RiskDecision(True, units, "ok")
