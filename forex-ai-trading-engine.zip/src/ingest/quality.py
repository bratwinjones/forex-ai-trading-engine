"""Data quality audit. Does not invent candles to fill gaps."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

import pandas as pd


FX_WEEKEND_GAP_HOURS = 48  # Fri close -> Sun open, expected
UNEXPECTED_GAP_HOURS = 3  # weekday hole larger than this is flagged
JUMP_PIPS = 50  # 50 pips on EURUSD = 0.0050 unexpected jump vs prior close


def expected_fx_weekend(prev: pd.Timestamp, curr: pd.Timestamp) -> bool:
    """True if gap looks like a normal FX weekend (Fri into Sun)."""
    hours = (curr - prev).total_seconds() / 3600.0
    if hours < 36:
        return False
    # Friday (4) or Saturday into Sunday
    return prev.weekday() in (4, 5) and curr.weekday() in (6, 0)


def audit_ohlc(df: pd.DataFrame, *, source: str, csv_path: str | None = None) -> dict:
    ts = pd.to_datetime(df["timestamp"], utc=True)
    n = len(df)
    dups = int(ts.duplicated().sum())
    ordered = bool(ts.is_monotonic_increasing)
    utc_ok = ts.dt.tz is not None

    o, h, l, c = df["open"], df["high"], df["low"], df["close"]
    invalid_ohlc = int(
        ((h < o) | (h < c) | (h < l) | (l > o) | (l > c) | (o <= 0) | (c <= 0)).sum()
    )

    deltas = ts.diff()
    gap_hours = deltas.dt.total_seconds() / 3600.0
    weekend_gaps = []
    unexpected_gaps = []
    for i in range(1, n):
        hours = float(gap_hours.iloc[i])
        if pd.isna(hours) or hours <= 1.01:
            continue
        prev, curr = ts.iloc[i - 1], ts.iloc[i]
        rec = {
            "from": str(prev),
            "to": str(curr),
            "hours": round(hours, 2),
        }
        if expected_fx_weekend(prev, curr) or (prev.weekday() >= 4 and hours < 72):
            weekend_gaps.append(rec)
        elif hours >= UNEXPECTED_GAP_HOURS:
            unexpected_gaps.append(rec)

    jumps = []
    prev_c = c.shift(1)
    move = (c - prev_c).abs()
    for i in move[move >= JUMP_PIPS * 0.0001].index.tolist()[:50]:
        if i == 0:
            continue
        jumps.append(
            {
                "timestamp": str(ts.iloc[i]),
                "move": float(move.iloc[i]),
                "from": float(prev_c.iloc[i]),
                "to": float(c.iloc[i]),
            }
        )

    zero_vol = None
    if "volume" in df.columns:
        z = pd.to_numeric(df["volume"], errors="coerce").fillna(0)
        zero_vol = int((z == 0).sum())

    large_spreads = None
    if "spread" in df.columns:
        sp = pd.to_numeric(df["spread"], errors="coerce")
        large_spreads = int((sp > 0.0005).sum())  # > 5 pips

    return {
        "source": source,
        "csv_path": csv_path,
        "audit_time_utc": datetime.now(timezone.utc).isoformat(),
        "n_candles": n,
        "start": str(ts.iloc[0]) if n else None,
        "end": str(ts.iloc[-1]) if n else None,
        "utc_timezone_ok": bool(utc_ok),
        "chronological": ordered,
        "duplicate_timestamps": dups,
        "invalid_ohlc_rows": invalid_ohlc,
        "weekend_or_closure_gaps": weekend_gaps[:40],
        "weekend_or_closure_gap_count": len(weekend_gaps),
        "unexpected_missing_gaps": unexpected_gaps[:40],
        "unexpected_missing_gap_count": len(unexpected_gaps),
        "large_jumps_ge_50_pips": jumps,
        "zero_volume_bars": zero_vol,
        "large_spread_bars": large_spreads,
        "invented_fill_candles": 0,
        "limitations": [],
    }


def write_quality_report(audit: dict, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    lim = audit.get("limitations") or []
    lines = [
        "# Data quality report",
        "",
        f"- **source**: {audit.get('source')}",
        f"- **csv_path**: {audit.get('csv_path')}",
        f"- **audit_time_utc**: {audit.get('audit_time_utc')}",
        f"- **download_date**: {audit.get('audit_time_utc')}",
        f"- **date_range**: {audit.get('start')} → {audit.get('end')}",
        f"- **n_candles**: {audit.get('n_candles')}",
        f"- **utc_timezone_ok**: {audit.get('utc_timezone_ok')}",
        f"- **chronological**: {audit.get('chronological')}",
        f"- **duplicate_timestamps**: {audit.get('duplicate_timestamps')}",
        f"- **invalid_ohlc_rows**: {audit.get('invalid_ohlc_rows')}",
        f"- **weekend_or_closure_gap_count**: {audit.get('weekend_or_closure_gap_count')}",
        f"- **unexpected_missing_gap_count**: {audit.get('unexpected_missing_gap_count')}",
        f"- **large_jumps_ge_50_pips**: {len(audit.get('large_jumps_ge_50_pips') or [])}",
        f"- **zero_volume_bars**: {audit.get('zero_volume_bars')}",
        f"- **large_spread_bars**: {audit.get('large_spread_bars')}",
        f"- **invented_fill_candles**: {audit.get('invented_fill_candles')} (must stay 0)",
        "",
        "## Unexpected gaps (weekday holes)",
    ]
    gaps = audit.get("unexpected_missing_gaps") or []
    if not gaps:
        lines.append("- none flagged")
    else:
        for g in gaps:
            lines.append(f"- {g}")
    lines += ["", "## Limitations"]
    if not lim:
        lines.append("- See data/SOURCE_NOTES.md")
    for x in lim:
        lines.append(f"- {x}")
    lines += [
        "",
        "Gaps are **not** filled with synthetic candles.",
        "",
    ]
    path.write_text("\n".join(lines), encoding="utf-8")
