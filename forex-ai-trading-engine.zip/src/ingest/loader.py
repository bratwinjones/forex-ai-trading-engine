from __future__ import annotations

from pathlib import Path

import pandas as pd

from .validate import validate_ohlc


def load_ohlc_csv(path: str | Path, timestamp_column: str = "timestamp") -> pd.DataFrame:
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"OHLC CSV not found: {path}")
    df = pd.read_csv(path)
    if timestamp_column != "timestamp" and timestamp_column in df.columns:
        df = df.rename(columns={timestamp_column: "timestamp"})
    return validate_ohlc(df)
