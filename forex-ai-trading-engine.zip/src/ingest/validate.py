"""Strict OHLC validation. Bad data is reported, never silently repaired."""

from __future__ import annotations

import pandas as pd

REQUIRED = ("timestamp", "open", "high", "low", "close")
OPTIONAL = ("volume", "spread")


class ValidationError(ValueError):
    """Market data failed validation; caller must fix the source file."""


def validate_ohlc(df: pd.DataFrame) -> pd.DataFrame:
    problems: list[str] = []
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        raise ValidationError(f"Missing required columns: {missing}")

    out = df.copy()
    extra = [c for c in out.columns if c not in REQUIRED + OPTIONAL]
    if extra:
        problems.append(f"Unknown columns ignored by schema (kept as-is): {extra}")

    ts = pd.to_datetime(out["timestamp"], utc=True, errors="coerce")
    if ts.isna().any():
        bad = out.index[ts.isna()].tolist()[:10]
        problems.append(f"Unparseable timestamps at rows {bad}")
    out["timestamp"] = ts

    if ts.notna().any() and (ts.dt.tz is None):
        problems.append("Timestamps are not UTC-aware after parse")

    for col in ("open", "high", "low", "close"):
        out[col] = pd.to_numeric(out[col], errors="coerce")
        if out[col].isna().any():
            problems.append(f"Missing/invalid numeric values in '{col}'")
        if (out[col].dropna() <= 0).any():
            problems.append(f"Non-positive prices in '{col}'")

    if "volume" in out.columns:
        out["volume"] = pd.to_numeric(out["volume"], errors="coerce")
    if "spread" in out.columns:
        out["spread"] = pd.to_numeric(out["spread"], errors="coerce")

    o, h, l, c = out["open"], out["high"], out["low"], out["close"]
    valid = o.notna() & h.notna() & l.notna() & c.notna()
    if valid.any():
        if not (h[valid] >= o[valid]).all():
            problems.append("high < open on one or more bars")
        if not (h[valid] >= c[valid]).all():
            problems.append("high < close on one or more bars")
        if not (h[valid] >= l[valid]).all():
            problems.append("high < low on one or more bars")
        if not (l[valid] <= o[valid]).all():
            problems.append("low > open on one or more bars")
        if not (l[valid] <= c[valid]).all():
            problems.append("low > close on one or more bars")

    ts_ok = out["timestamp"].notna()
    if ts_ok.sum() > 1:
        ordered = out.loc[ts_ok, "timestamp"]
        if not ordered.is_monotonic_increasing:
            problems.append("Timestamps are not chronological")
        if ordered.duplicated().any():
            problems.append("Duplicate timestamps")

    fatal = [
        p
        for p in problems
        if not p.startswith("Unknown columns")
    ]
    if fatal:
        raise ValidationError("OHLC validation failed:\n- " + "\n- ".join(fatal))
    return out.reset_index(drop=True)
